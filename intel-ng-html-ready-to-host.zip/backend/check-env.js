#!/usr/bin/env node
/**
 * Vérifie Node >= 22 et la config avant démarrage / déploiement
 * Usage: node check-env.js
 */
const path = require("path");
const fs = require("fs");

try {
  require("./load-env").loadEnv();
} catch (e) {}

const major = Number(process.versions.node.split(".")[0]);
let ok = true;

function fail(msg) {
  console.error("✗", msg);
  ok = false;
}
function pass(msg) {
  console.log("✓", msg);
}

console.log("Node:", process.version);
if (major < 22) fail("Node.js >= 22 requis (actuel: " + process.version + ")");
else pass("Node.js >= 22");

const isProd = process.env.NODE_ENV === "production";
console.log("NODE_ENV:", process.env.NODE_ENV || "(non défini → development)");

if (isProd) {
  const secret = process.env.JWT_SECRET || "";
  if (!secret || secret.length < 24 || secret === "intel-ng-dev-secret-change-me") {
    fail("JWT_SECRET manquant ou trop faible (min 24 car., pas le secret dev)");
  } else pass("JWT_SECRET OK (" + secret.length + " car.)");

  const email = (process.env.ADMIN_EMAIL || "").trim();
  const passw = process.env.ADMIN_PASSWORD || "";
  if (!email || !email.includes("@")) fail("ADMIN_EMAIL obligatoire en production");
  else pass("ADMIN_EMAIL OK");
  if (passw.length < 12) fail("ADMIN_PASSWORD trop court en prod (min 12)");
  else pass("ADMIN_PASSWORD OK");

  const dataDir = process.env.INTEL_NG_DATA_DIR || path.join(__dirname, "data");
  try {
    fs.mkdirSync(dataDir, { recursive: true });
    pass("INTEL_NG_DATA_DIR accessible: " + dataDir);
  } catch (e) {
    fail("INTEL_NG_DATA_DIR inaccessible: " + dataDir + " — " + (e && e.message));
  }
} else {
  pass("Mode development — secrets stricts non exigés");
  if (!process.env.JWT_SECRET) {
    console.warn("⚠ JWT_SECRET non défini (secret dev utilisé)");
  }
}

const envFile = path.join(__dirname, ".env");
if (fs.existsSync(envFile)) pass("Fichier .env présent");
else console.warn("⚠ Pas de fichier .env — copiez .env.example → .env");

if (!ok) {
  console.error("\nÉchec check-env. Corrigez puis relancez.");
  process.exit(1);
}
if (process.env.DATABASE_URL) pass("DATABASE_URL défini (Postgres multi-serveur)");
else pass("SQLite (1 instance PM2) — OK pour démarrer");

if (process.env.RESEND_API_KEY || process.env.EMAIL_WEBHOOK_URL) pass("Email configuré");
else console.warn("⚠ Email non configuré (outbox seul)");
if (process.env.TWILIO_ACCOUNT_SID || process.env.SMS_WEBHOOK_URL) pass("SMS configuré");
else console.warn("⚠ SMS non configuré (outbox seul)");

console.log("\ncheck-env OK — vous pouvez démarrer: node server.js");
