# Backend Intel NG (SQLite + backups + PM2)

## Prérequis
- **Node.js ≥ 22** (utilise `node:sqlite` natif, zéro dépendance npm)

## Démarrage rapide
```bash
cd backend
node server.js
# → http://127.0.0.1:8787
```

### Variable d’environnement
| Variable | Description |
|----------|-------------|
| `PORT` | Port HTTP (défaut `8787`) |
| `JWT_SECRET` | Secret JWT (**obligatoire en prod**) |
| `INTEL_NG_DATA_DIR` | Dossier data SQLite + backups (défaut `backend/data`) |

> Sur certains FS réseau, placez les data sur un **disque local** :
> `export INTEL_NG_DATA_DIR=/var/lib/intel-ng`

## 6. SQLite
Fichier : `$INTEL_NG_DATA_DIR/intel-ng.sqlite`  
Migration auto depuis l’ancien `db.json` au premier démarrage.

## 7. Backups
- Automatique **au démarrage** + **toutes les 24 h**
- Conservation **14 jours**
- CLI :
```bash
node scripts-backup.js backup
node scripts-backup.js list
node scripts-backup.js restore intel-ng-daily-….sqlite
```
- API admin : `GET/POST /api/admin/backups`

## 8. Process manager
### PM2
```bash
npm i -g pm2
pm2 start ecosystem.config.cjs
pm2 save && pm2 startup
```
### systemd
```bash
sudo cp deploy/intel-ng.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now intel-ng
```

## 9. Health / monitoring
```bash
curl http://127.0.0.1:8787/api/health
```
Réponse : `status`, `uptimeSec`, `users`, `pendingDeposits`, `backups`, `memoryMB`.

UptimeRobot / cron : voir `deploy/crontab.example`.

## Admin défaut
`wilstontadia@gmail.com` / `IntelNG@2026` — **à changer en production**.

## Optimisations SQLite
- Statements préparés en cache
- Cache catalogue / settings (15 s)
- Historiques limités (300 dépôts/retraits, 200 tickets/logs)
- Réécriture catalogue **uniquement** si les machines changent
- `PRAGMA synchronous=NORMAL`, `temp_store=MEMORY`


Voir aussi `docs/SECURITY.md` (JWT, rate-limit, preuves, audit).

## Mot de passe oublié
- `POST /api/auth/forgot` `{ phone }`
- `POST /api/auth/reset` `{ phone, code, password }`
- SMS/Email via `notify.js` (outbox + webhooks `EMAIL_WEBHOOK_URL` / `SMS_WEBHOOK_URL`)

## Preuves hors DB
- Fichiers dans `$INTEL_NG_DATA_DIR/proofs/`
- URL publique `/media/proofs/...`
- SQLite ne stocke que le chemin (+ hash anti-doublon)

## Postgres multi-serveur
Voir `docs/POSTGRES.md` et `backend/deploy/schema-postgres.sql`
