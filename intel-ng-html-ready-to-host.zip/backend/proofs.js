/**
 * Preuves dépôt hors DB
 * - Disque local ou NFS : INTEL_NG_PROOFS_DIR (défaut data/proofs)
 * - Option S3/R2/MinIO : S3_BUCKET + S3_ACCESS_KEY + S3_SECRET_KEY (+ S3_ENDPOINT)
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const https = require("https");
const http = require("http");

function dataDir() {
  return process.env.INTEL_NG_DATA_DIR || path.join(__dirname, "data");
}

function proofsDir() {
  const d = process.env.INTEL_NG_PROOFS_DIR || path.join(dataDir(), "proofs");
  fs.mkdirSync(d, { recursive: true });
  return d;
}

function s3Enabled() {
  return !!(process.env.S3_BUCKET && process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY);
}

function hmac(key, data) {
  return crypto.createHmac("sha256", key).update(data, "utf8").digest();
}
function hashHex(data) {
  return crypto.createHash("sha256").update(data).digest("hex");
}

/** PutObject S3-compatible (AWS / R2 / MinIO) */
function s3Put(filename, buf, contentType) {
  return new Promise((resolve, reject) => {
    const bucket = process.env.S3_BUCKET;
    const region = process.env.S3_REGION || "auto";
    const endpoint = process.env.S3_ENDPOINT; // ex. https://xxx.r2.cloudflarestorage.com
    const accessKey = process.env.S3_ACCESS_KEY;
    const secretKey = process.env.S3_SECRET_KEY;
    const key = (process.env.S3_PREFIX || "proofs/") + filename;
    const host = endpoint ? new URL(endpoint).host : bucket + ".s3." + region + ".amazonaws.com";
    const pathUrl = endpoint ? "/" + bucket + "/" + key : "/" + key;
    const method = "PUT";
    const amzDate = new Date().toISOString().replace(/[:-]|\.\d{3}/g, "");
    const dateStamp = amzDate.slice(0, 8);
    const payloadHash = hashHex(buf);
    const canonicalHeaders =
      "host:" + host + "\n" + "x-amz-content-sha256:" + payloadHash + "\n" + "x-amz-date:" + amzDate + "\n";
    const signedHeaders = "host;x-amz-content-sha256;x-amz-date";
    const canonicalRequest = [method, pathUrl, "", canonicalHeaders, signedHeaders, payloadHash].join("\n");
    const credentialScope = dateStamp + "/" + region + "/s3/aws4_request";
    const stringToSign = ["AWS4-HMAC-SHA256", amzDate, credentialScope, hashHex(canonicalRequest)].join("\n");
    const kDate = hmac("AWS4" + secretKey, dateStamp);
    const kRegion = hmac(kDate, region);
    const kService = hmac(kRegion, "s3");
    const kSigning = hmac(kService, "aws4_request");
    const signature = crypto.createHmac("sha256", kSigning).update(stringToSign, "utf8").digest("hex");
    const authorization =
      "AWS4-HMAC-SHA256 Credential=" +
      accessKey +
      "/" +
      credentialScope +
      ", SignedHeaders=" +
      signedHeaders +
      ", Signature=" +
      signature;

    const lib = (endpoint || "").startsWith("http://") ? http : https;
    const req = lib.request(
      {
        hostname: host,
        path: pathUrl,
        method,
        headers: {
          Host: host,
          "Content-Type": contentType,
          "Content-Length": buf.length,
          "x-amz-content-sha256": payloadHash,
          "x-amz-date": amzDate,
          Authorization: authorization,
        },
      },
      (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => {
          if (res.statusCode >= 200 && res.statusCode < 300) resolve({ ok: true, key });
          else reject(new Error("s3_put_" + res.statusCode + ":" + body.slice(0, 200)));
        });
      }
    );
    req.on("error", reject);
    req.write(buf);
    req.end();
  });
}

function publicUrl(filename) {
  if (process.env.S3_PUBLIC_BASE) {
    return String(process.env.S3_PUBLIC_BASE).replace(/\/$/, "") + "/" + filename;
  }
  return "/media/proofs/" + filename;
}

function saveProof(dataUrl, id) {
  const s = String(dataUrl || "");
  const m = s.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!m) throw new Error("proof_type");
  const mime = m[1].toLowerCase();
  const ext =
    mime.includes("png") ? "png" : mime.includes("webp") ? "webp" : mime.includes("gif") ? "gif" : "jpg";
  const buf = Buffer.from(m[2], "base64");
  if (buf.length > 2_500_000) throw new Error("proof_too_large");
  const safeId = String(id || crypto.randomBytes(8).toString("hex")).replace(/[^a-zA-Z0-9_-]/g, "");
  const filename = safeId + "." + ext;
  const full = path.join(proofsDir(), filename);
  fs.writeFileSync(full, buf);

  const result = {
    path: "proofs/" + filename,
    url: publicUrl(filename),
    size: buf.length,
    storage: "disk",
  };

  if (s3Enabled()) {
    const contentType = mime.startsWith("image/") ? mime : "application/octet-stream";
    s3Put(filename, buf, contentType)
      .then(() => {
        console.log("[proofs] S3 ok", filename);
      })
      .catch((e) => {
        console.error("[proofs] S3 upload failed, local/NFS kept:", e.message);
      });
    result.storage = "disk+s3_pending";
  }

  return result;
}

function resolveProofFile(rel) {
  if (!rel || String(rel).includes("..")) return null;
  // external URL
  if (String(rel).startsWith("http://") || String(rel).startsWith("https://")) return null;
  const name = path.basename(String(rel).replace(/^proofs\//, "").replace(/^\/media\/proofs\//, ""));
  const full = path.join(proofsDir(), name);
  if (!fs.existsSync(full)) return null;
  return full;
}

function proofFingerprint(dataUrl) {
  const s = String(dataUrl || "");
  const b64 = s.includes(",") ? s.split(",")[1] : s;
  return crypto.createHash("sha256").update(b64.slice(0, 8000) + ":" + b64.length).digest("hex");
}

module.exports = { saveProof, resolveProofFile, proofFingerprint, proofsDir, s3Enabled };
