#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "=== Intel NG deploy check ==="
node -v
node check-env.js
echo "Syntax..."
node --check server.js
node --check db.js
test -f ../index.html
echo "OK — démarrez: node server.js  ou  pm2 start ecosystem.config.cjs"
