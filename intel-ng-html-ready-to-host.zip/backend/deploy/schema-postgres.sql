-- Intel NG — schéma PostgreSQL (multi-serveur)
-- Créer la base puis: psql $DATABASE_URL -f schema-postgres.sql
-- Puis: npm install pg && export DATABASE_URL=postgres://...

CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  phone TEXT UNIQUE,
  name TEXT,
  password_hash TEXT,
  balance DOUBLE PRECISION DEFAULT 0,
  income DOUBLE PRECISION DEFAULT 0,
  invite TEXT,
  referred_by TEXT,
  status TEXT DEFAULT 'actif',
  owned TEXT,
  claim_log TEXT,
  email TEXT,
  reset_code TEXT,
  reset_expires BIGINT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS admins (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE,
  name TEXT,
  password_hash TEXT,
  role TEXT DEFAULT 'admin'
);
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  category TEXT,
  name TEXT,
  price DOUBLE PRECISION,
  daily DOUBLE PRECISION,
  days INT,
  image TEXT,
  max_buys INT,
  sort_order INT DEFAULT 0
);
CREATE TABLE IF NOT EXISTS deposits (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  phone TEXT,
  amount DOUBLE PRECISION,
  provider TEXT,
  account_name TEXT,
  screenshot TEXT,
  proof_hash TEXT,
  country TEXT,
  dial TEXT,
  status TEXT DEFAULT 'pending',
  reject_reason TEXT,
  created_at TEXT,
  reviewed_at TEXT,
  client_at TEXT,
  submitted_label TEXT
);
CREATE TABLE IF NOT EXISTS withdrawals (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  phone TEXT,
  amount DOUBLE PRECISION,
  method TEXT,
  mobile_provider TEXT,
  mobile_number TEXT,
  account_name TEXT,
  status TEXT DEFAULT 'pending',
  reject_reason TEXT,
  created_at TEXT,
  reviewed_at TEXT,
  client_at TEXT,
  submitted_label TEXT
);
CREATE TABLE IF NOT EXISTS support_tickets (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  name TEXT,
  email TEXT,
  subject TEXT,
  message TEXT,
  status TEXT,
  admin_reply TEXT,
  created_at TEXT,
  answered_at TEXT
);
CREATE TABLE IF NOT EXISTS activity_log (
  id TEXT PRIMARY KEY,
  action TEXT,
  detail TEXT,
  at TEXT
);
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  title TEXT,
  body TEXT,
  type TEXT,
  read_flag INT DEFAULT 0,
  created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_dep_user ON deposits(user_id);
CREATE INDEX IF NOT EXISTS idx_dep_status ON deposits(status);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
