/**
 * Email (Resend) + SMS (Twilio) + webhooks + outbox local
 */
const fs = require("fs");
const path = require("path");
const https = require("https");
const http = require("http");

function dataDir() {
  return process.env.INTEL_NG_DATA_DIR || path.join(__dirname, "data");
}
function outboxDir() {
  const d = path.join(dataDir(), "outbox");
  fs.mkdirSync(d, { recursive: true });
  return d;
}
function saveOutbox(channel, payload) {
  const file = path.join(outboxDir(), channel + "_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6) + ".json");
  fs.writeFileSync(file, JSON.stringify({ at: new Date().toISOString(), channel, ...payload }, null, 2));
  return file;
}

function requestJson(method, urlStr, body, headers) {
  return new Promise((resolve, reject) => {
    let u;
    try {
      u = new URL(urlStr);
    } catch (e) {
      return reject(e);
    }
    const lib = u.protocol === "https:" ? https : http;
    const data = body == null ? null : typeof body === "string" ? body : JSON.stringify(body);
    const req = lib.request(
      {
        hostname: u.hostname,
        port: u.port || (u.protocol === "https:" ? 443 : 80),
        path: u.pathname + u.search,
        method,
        headers: Object.assign(
          {
            "Content-Type": "application/json",
            ...(data ? { "Content-Length": Buffer.byteLength(data) } : {}),
          },
          headers || {}
        ),
      },
      (res) => {
        let buf = "";
        res.on("data", (c) => (buf += c));
        res.on("end", () => resolve({ status: res.statusCode, body: buf }));
      }
    );
    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

async function sendEmail({ to, subject, text }) {
  const from = process.env.EMAIL_FROM || "Intel NG <onboarding@resend.dev>";
  const payload = { to, subject, text, from };
  saveOutbox("email", payload);
  console.log("[notify:email]", to, subject);

  // Resend API
  if (process.env.RESEND_API_KEY) {
    try {
      const r = await requestJson(
        "POST",
        "https://api.resend.com/emails",
        { from, to: [to], subject, text },
        { Authorization: "Bearer " + process.env.RESEND_API_KEY }
      );
      if (r.status >= 200 && r.status < 300) return { ok: true, channel: "email", via: "resend" };
      console.error("[notify:email] resend", r.status, r.body);
      return { ok: false, error: "resend_" + r.status };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  if (process.env.EMAIL_WEBHOOK_URL) {
    try {
      await requestJson("POST", process.env.EMAIL_WEBHOOK_URL, payload, {
        Authorization: process.env.NOTIFY_API_KEY ? "Bearer " + process.env.NOTIFY_API_KEY : undefined,
      });
      return { ok: true, channel: "email", via: "webhook" };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }
  return { ok: true, channel: "email", via: "outbox" };
}

async function sendSms({ to, text }) {
  const payload = { to, text };
  saveOutbox("sms", payload);
  console.log("[notify:sms]", to, String(text).slice(0, 80));

  // Twilio
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM;
  if (sid && token && from) {
    try {
      const auth = Buffer.from(sid + ":" + token).toString("base64");
      const body =
        "To=" +
        encodeURIComponent(to) +
        "&From=" +
        encodeURIComponent(from) +
        "&Body=" +
        encodeURIComponent(text);
      const r = await new Promise((resolve, reject) => {
        const u = new URL("https://api.twilio.com/2010-04-01/Accounts/" + sid + "/Messages.json");
        const req = https.request(
          {
            hostname: u.hostname,
            path: u.pathname,
            method: "POST",
            headers: {
              Authorization: "Basic " + auth,
              "Content-Type": "application/x-www-form-urlencoded",
              "Content-Length": Buffer.byteLength(body),
            },
          },
          (res) => {
            let buf = "";
            res.on("data", (c) => (buf += c));
            res.on("end", () => resolve({ status: res.statusCode, body: buf }));
          }
        );
        req.on("error", reject);
        req.write(body);
        req.end();
      });
      if (r.status >= 200 && r.status < 300) return { ok: true, channel: "sms", via: "twilio" };
      console.error("[notify:sms] twilio", r.status, r.body);
      return { ok: false, error: "twilio_" + r.status };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  if (process.env.SMS_WEBHOOK_URL) {
    try {
      await requestJson("POST", process.env.SMS_WEBHOOK_URL, payload, {
        Authorization: process.env.NOTIFY_API_KEY ? "Bearer " + process.env.NOTIFY_API_KEY : undefined,
      });
      return { ok: true, channel: "sms", via: "webhook" };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }
  return { ok: true, channel: "sms", via: "outbox" };
}

async function notifyUser(user, { subject, text, prefer }) {
  const phone = user && user.phone;
  const email = user && user.email;
  const results = [];
  if (prefer === "email" && email) results.push(await sendEmail({ to: email, subject, text }));
  else if (prefer === "sms" && phone) results.push(await sendSms({ to: phone, text: subject ? subject + " — " + text : text }));
  else {
    if (phone) results.push(await sendSms({ to: phone, text: subject ? subject + " — " + text : text }));
    if (email) results.push(await sendEmail({ to: email, subject: subject || "Intel NG", text }));
  }
  return results;
}

module.exports = { sendEmail, sendSms, notifyUser, saveOutbox };
