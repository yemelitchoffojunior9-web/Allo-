#!/usr/bin/env node
/**
 * Backup / restore CLI
 *   node scripts-backup.js backup
 *   node scripts-backup.js list
 *   node scripts-backup.js restore <filename>
 */
const db = require("./db");
const cmd = process.argv[2] || "backup";
const arg = process.argv[3];

if (cmd === "backup") {
  const p = db.backupNow("cli");
  console.log("OK", p);
  process.exit(0);
}
if (cmd === "list") {
  db.listBackups().forEach((b) => console.log(b.mtime, b.size, b.name));
  process.exit(0);
}
if (cmd === "restore") {
  if (!arg) {
    console.error("Usage: node scripts-backup.js restore <file.sqlite>");
    process.exit(1);
  }
  db.restoreBackup(arg);
  console.log("Restored", arg);
  process.exit(0);
}
if (cmd === "health") {
  console.log(JSON.stringify(db.health(), null, 2));
  process.exit(db.health().ok ? 0 : 1);
}
console.error("Commands: backup | list | restore <file> | health");
process.exit(1);
