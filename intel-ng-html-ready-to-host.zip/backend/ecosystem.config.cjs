/**
 * PM2 — 1 instance (SQLite)
 * cp .env.example .env  puis:  pm2 start ecosystem.config.cjs
 */
module.exports = {
  apps: [
    {
      name: "intel-ng",
      script: "server.js",
      cwd: __dirname,
      instances: 1,
      exec_mode: "fork",
      watch: false,
      max_memory_restart: "300M",
      exp_backoff_restart_delay: 1000,
      /* Charge automatiquement backend/.env si présent (PM2 >= 5) */
      env_file: ".env",
      env: {
        NODE_ENV: "production",
        PORT: "8787",
      },
      error_file: "data/logs/err.log",
      out_file: "data/logs/out.log",
      merge_logs: true,
      time: true,
    },
  ],
};
