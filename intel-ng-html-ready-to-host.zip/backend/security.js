/**
 * Sécurité Intel NG — rate-limit, validation preuves, sanitize, audit append-only
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const IS_PROD = process.env.NODE_ENV === "production";
const JWT_SECRET = process.env.JWT_SECRET || (IS_PROD ? "" : "intel-ng-dev-secret-change-me");
const MAX_PROOF_CHARS = Number(process.env.MAX_PROOF_CHARS) || 1_800_000; // ~1.3 Mo base64
const ALLOWED_PROOF_PREFIXES = [
  "data:image/jpeg;base64,",
  "data:image/jpg;base64,",
  "data:image/png;base64,",
  "data:image/webp;base64,",
];

/* ---- Rate limit en mémoire (par process) ---- */
const buckets = new Map();

function clientKey(req, extra) {
  const xf = (req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  const ip = xf || req.socket.remoteAddress || "unknown";
  return ip + "|" + (extra || "");
}

/**
 * @returns {null|string} error code if limited
 */
function rateLimit(req, name, max, windowMs) {
  const key = name + "::" + clientKey(req);
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || now > b.reset) {
    b = { count: 0, reset: now + windowMs };
    buckets.set(key, b);
  }
  b.count++;
  if (b.count > max) return "rate_limit";
  return null;
}

/* purge occasionnelle */
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of buckets) {
    if (now > v.reset) buckets.delete(k);
  }
}, 60_000).unref?.();

/* ---- Sanitize / XSS ---- */
function stripTags(s) {
  return String(s || "")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function cleanText(s, max) {
  return stripTags(String(s || "").trim()).slice(0, max || 500);
}

/* ---- Preuve dépôt ---- */
function validateProof(screenshot) {
  if (!screenshot) return { ok: false, error: "proof_required" };
  const s = String(screenshot);
  if (s.length > MAX_PROOF_CHARS) return { ok: false, error: "proof_too_large" };
  const lower = s.slice(0, 40).toLowerCase();
  const okType = ALLOWED_PROOF_PREFIXES.some((p) => lower.startsWith(p));
  if (!okType) return { ok: false, error: "proof_type" };
  return { ok: true };
}

function validateAmount(amount, min, max) {
  const n = Number(amount);
  if (!Number.isFinite(n) || n !== Math.floor(n)) return "invalid_amount";
  if (!(n >= min)) return "min_amount";
  if (!(n <= max)) return "max_amount";
  if (n % 500 !== 0) return "step_amount";
  return null;
}

/* ---- Audit append-only (fichier journal) ---- */
function auditPath(dataDir) {
  return path.join(dataDir || path.join(__dirname, "data"), "audit.jsonl");
}

function auditAppend(dataDir, entry) {
  try {
    const line =
      JSON.stringify(
        Object.assign(
          {
            at: new Date().toISOString(),
            id: "aud_" + Date.now().toString(36) + crypto.randomBytes(3).toString("hex"),
          },
          entry
        )
      ) + "\n";
    fs.appendFileSync(auditPath(dataDir), line, { encoding: "utf8", flag: "a" });
  } catch (e) {
    console.error("[audit]", e && e.message);
  }
}

function assertJwtSecret() {
  if (IS_PROD && (!JWT_SECRET || JWT_SECRET === "intel-ng-dev-secret-change-me" || JWT_SECRET.length < 24)) {
    console.error("FATAL: JWT_SECRET manquant ou trop faible en production (min 24 caractères).");
    process.exit(1);
  }
  if (!IS_PROD && JWT_SECRET === "intel-ng-dev-secret-change-me") {
    console.warn("[security] JWT_SECRET par défaut (dev). Changez-le en production.");
  }
}

function parseCookies(req) {
  const h = req.headers.cookie || "";
  const out = {};
  h.split(";").forEach((p) => {
    const i = p.indexOf("=");
    if (i < 0) return;
    out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}

function cookieHeader(name, value, maxAgeSec) {
  const parts = [
    name + "=" + encodeURIComponent(value),
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    "Max-Age=" + String(maxAgeSec || 86400),
  ];
  if (IS_PROD) parts.push("Secure");
  return parts.join("; ");
}

function clearCookieHeader(name) {
  return name + "=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0" + (IS_PROD ? "; Secure" : "");
}

function normalizePhone(phone, defaultDial) {
  var d = String(phone || "").replace(/\s+/g, "").trim();
  var digits = d.replace(/\D/g, "");
  if (d.indexOf("+") === 0) return "+" + digits;
  /* Cameroun: 9 chiffres locaux → +237 */
  if (digits.length === 9 && (digits[0] === "6" || digits[0] === "2")) {
    return (defaultDial || "+237") + digits;
  }
  if (digits.length >= 7) return "+" + digits;
  return d;
}

module.exports = {
  normalizePhone,

  IS_PROD,
  JWT_SECRET,
  rateLimit,
  clientKey,
  stripTags,
  cleanText,
  validateProof,
  validateAmount,
  auditAppend,
  assertJwtSecret,
  parseCookies,
  cookieHeader,
  clearCookieHeader,
  MAX_PROOF_CHARS,
};
