/**
 * PostgreSQL multi-serveur (snapshot JSONB + pg_advisory_xact_lock)
 * API async : update/read via warm() cache ; update retourne une Promise.
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { Pool } = require("pg");

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
const DATA_DIR = process.env.INTEL_NG_DATA_DIR || path.join(__dirname, "data");
const BACKUP_DIR = path.join(DATA_DIR, "backups");
const LOCK_KEY = 742891;
let cache = null;

function uid(prefix) {
  return (prefix || "id") + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), salt, 32).toString("hex");
  return salt + ":" + hash;
}
function verifyPassword(password, stored) {
  if (!stored || stored.indexOf(":") < 0) return false;
  const [salt, hash] = stored.split(":");
  const check = crypto.scryptSync(String(password), salt, 32).toString("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(check, "hex"));
  } catch (e) {
    return false;
  }
}
function productsSeed() {
  return {
    Activité: [
      { id: "c1", name: "Pack Bienvenue", price: 3000, daily: 286, days: 21, image: "img/machines/thumbs/cpu1.jpg", maxBuys: 10 },
      { id: "c2", name: "Boost Week-end", price: 8000, daily: 1429, days: 14, image: "img/machines/thumbs/cpu3.jpg", maxBuys: 10 },
    ],
    Basique: [{ id: "s1", name: "Node Starter i3", price: 12000, daily: 640, days: 40, image: "img/machines/thumbs/chip-intel-conn.jpg" }],
    Avancé: [{ id: "ai1", name: "Node AI Inference", price: 45000, daily: 2700, days: 45, image: "img/machines/thumbs/chip-ati.jpg" }],
    Premium: [{ id: "lm1", name: "Node Limited Edition", price: 100000, daily: 6000, days: 50, image: "img/machines/thumbs/chip-dark.jpg" }],
  };
}
function emptyState() {
  const st = {
    users: [],
    admins: [],
    products: productsSeed(),
    deposits: [],
    withdrawals: [],
    supportTickets: [],
    activityLog: [],
    notifications: [],
    settings: {
      minDeposit: 2000,
      maxDeposit: 500000,
      minWithdraw: 2000,
      maxWithdraw: 500000,
      minPassword: 6,
      maintenance: false,
      referralBonusPercent: 25,
    },
    paymentMethods: {
      mobileMoney: {
        enabled: true,
        providers: [
          { name: "MTN MoMo", number: "670 000 001", accountName: "Intel NG SARL" },
          { name: "Orange Money", number: "690 000 002", accountName: "Intel NG SARL" },
          { name: "Wave", number: "670 000 003", accountName: "Intel NG SARL" },
        ],
      },
    },
    stats: { logins: 0 },
  };
  const email = (process.env.ADMIN_EMAIL || "admin@intel-ng.local").toLowerCase();
  const pass = process.env.ADMIN_PASSWORD || "ChangeMe@2026";
  st.admins.push({ id: "adm1", email, name: "Admin", passwordHash: hashPassword(pass), role: "super" });
  return st;
}

async function ensureSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS intel_snapshot (
      id INT PRIMARY KEY DEFAULT 1,
      data JSONB NOT NULL,
      updated_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS intel_meta (
      key TEXT PRIMARY KEY,
      value TEXT
    );
  `);
  const r = await pool.query("SELECT 1 FROM intel_snapshot WHERE id=1");
  if (!r.rowCount) {
    await pool.query("INSERT INTO intel_snapshot(id, data) VALUES(1, $1::jsonb)", [JSON.stringify(emptyState())]);
  }
}

async function warm() {
  await ensureSchema();
  const r = await pool.query("SELECT data FROM intel_snapshot WHERE id=1");
  cache = r.rows[0].data;
  return cache;
}

function read() {
  if (!cache) throw new Error("pg_not_warmed");
  return JSON.parse(JSON.stringify(cache));
}

function update(mutator) {
  return (async () => {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query("SELECT pg_advisory_xact_lock($1)", [LOCK_KEY]);
      const r = await client.query("SELECT data FROM intel_snapshot WHERE id=1 FOR UPDATE");
      const snapshot = r.rows[0].data;
      mutator(snapshot);
      await client.query("UPDATE intel_snapshot SET data=$1::jsonb, updated_at=NOW() WHERE id=1", [
        JSON.stringify(snapshot),
      ]);
      await client.query("COMMIT");
      cache = snapshot;
      return snapshot;
    } catch (e) {
      try {
        await client.query("ROLLBACK");
      } catch (e2) {}
      throw e;
    } finally {
      client.release();
    }
  })();
}

function write(data) {
  return update((d) => {
    Object.keys(d).forEach((k) => delete d[k]);
    Object.assign(d, data);
  });
}

function log(database, action, detail) {
  database.activityLog = database.activityLog || [];
  database.activityLog.unshift({ id: uid("log"), action, detail: detail || "", at: new Date().toISOString() });
  if (database.activityLog.length > 500) database.activityLog.length = 500;
}

function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id,
    phone: u.phone,
    name: u.name,
    balance: Number(u.balance) || 0,
    income: Number(u.income) || 0,
    points: Number(u.points) || 0,
    owned: u.owned || [],
    invite: u.invite,
    referrals: u.referrals || [],
    referralEarnings: Number(u.referralEarnings) || 0,
    status: u.status || "actif",
    country: u.country,
    dial: u.dial,
  };
}

function setMeta(key, value) {
  return pool.query(
    "INSERT INTO intel_meta(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value",
    [key, String(value)]
  );
}
function getMeta(key) {
  return pool.query("SELECT value FROM intel_meta WHERE key=$1", [key]).then((r) => (r.rows[0] ? r.rows[0].value : null));
}

function pushNotification(userId, title, body, type) {
  return update((d) => {
    d.notifications = d.notifications || [];
    d.notifications.unshift({
      id: uid("n"),
      userId,
      title: title || "",
      body: body || "",
      type: type || "info",
      read: false,
      at: new Date().toISOString(),
    });
  });
}
function listNotifications(userId, limit) {
  return (read().notifications || []).filter((n) => n.userId === userId).slice(0, limit || 50);
}
function markNotificationsRead(userId, id) {
  return update((d) => {
    (d.notifications || []).forEach((n) => {
      if (n.userId === userId && (!id || n.id === id)) n.read = true;
    });
  });
}

function backupNow() {
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const dest = path.join(BACKUP_DIR, "pg-" + Date.now() + ".json");
  fs.writeFileSync(dest, JSON.stringify(read()));
  return dest;
}
function listBackups() {
  if (!fs.existsSync(BACKUP_DIR)) return [];
  return fs.readdirSync(BACKUP_DIR).filter((f) => f.startsWith("pg-"));
}
function health() {
  try {
    return { ok: true, engine: "postgres", users: (cache && cache.users && cache.users.length) || 0 };
  } catch (e) {
    return { ok: false, error: String(e.message) };
  }
}
function close() {
  return pool.end();
}

module.exports = {
  DATA_DIR,
  uid,
  read,
  write,
  update,
  log,
  publicUser,
  hashPassword,
  verifyPassword,
  pushNotification,
  listNotifications,
  markNotificationsRead,
  setMeta,
  getMeta,
  backupNow,
  listBackups,
  health,
  close,
  warm,
  engine: "postgres",
  isAsync: true,
};
