/**
 * Charge backend/.env sans dépendance npm (KEY=VALUE, ignore # et lignes vides)
 */
const fs = require("fs");
const path = require("path");

function loadEnv(filePath) {
  const p = filePath || path.join(__dirname, ".env");
  if (!fs.existsSync(p)) return false;
  const text = fs.readFileSync(p, "utf8");
  text.split(/\n/).forEach((line) => {
    const s = line.trim();
    if (!s || s.startsWith("#")) return;
    const i = s.indexOf("=");
    if (i < 1) return;
    const key = s.slice(0, i).trim();
    let val = s.slice(i + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  });
  return true;
}

module.exports = { loadEnv };
