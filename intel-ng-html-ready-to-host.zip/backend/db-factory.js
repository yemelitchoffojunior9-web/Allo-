/**
 * Choisit SQLite (défaut) ou PostgreSQL si DATABASE_URL est défini.
 */
try {
  require("./load-env").loadEnv();
} catch (e) {}

let db;
if (process.env.DATABASE_URL) {
  try {
    db = require("./db-pg");
    console.log("[db] engine: postgres");
  } catch (e) {
    console.error("[db] PostgreSQL demandé mais pg indisponible:", e.message);
    console.error("→ npm install pg   ou retirez DATABASE_URL");
    process.exit(1);
  }
} else {
  db = require("./db");
  db.engine = "sqlite";
  db.isAsync = false;
  db.warm = async function () {
    return true;
  };
}

module.exports = db;
