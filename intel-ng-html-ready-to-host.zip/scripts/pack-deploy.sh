#!/usr/bin/env bash
# Crée une archive de déploiement complète (front + img + backend, sans secrets)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/../intel-ng-deploy.zip}"
cd "$ROOT"
zip -qr "$OUT" . \
  -x "backend/node_modules/*" \
  -x "backend/.env" \
  -x "backend/data/*.sqlite*" \
  -x "backend/data/backups/*" \
  -x "backend/data/proofs/*" \
  -x "backend/data/outbox/*" \
  -x "lighthouse-reports/*" \
  -x ".git/*" \
  -x "*.DS_Store"
echo "Pack: $OUT"
ls -lh "$OUT"
