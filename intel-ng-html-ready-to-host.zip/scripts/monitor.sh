#!/usr/bin/env bash
# Surveillance uptime Intel NG
# Usage: ./scripts/monitor.sh https://votredomaine.com
# Cron: */5 * * * * /path/to/scripts/monitor.sh https://votredomaine.com >> /var/log/intel-ng-monitor.log 2>&1

set -euo pipefail
BASE="${1:-http://127.0.0.1:8787}"
WEBHOOK="${MONITOR_WEBHOOK_URL:-}"
TIMEOUT=15

ts() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }

code=$(curl -s -o /tmp/intel-ng-health.json -w "%{http_code}" --max-time "$TIMEOUT" "$BASE/api/health" || echo "000")
body=$(cat /tmp/intel-ng-health.json 2>/dev/null || echo "{}")

if [ "$code" != "200" ]; then
  msg="[ALERT $(ts)] Intel NG DOWN http=$code url=$BASE"
  echo "$msg"
  if [ -n "$WEBHOOK" ]; then
    curl -s -X POST -H "Content-Type: application/json" \
      -d "{\"text\":\"$msg\",\"content\":\"$msg\"}" "$WEBHOOK" >/dev/null || true
  fi
  exit 2
fi

# Parse ok field
ok=$(node -e "try{const j=require('/tmp/intel-ng-health.json');console.log(j.ok||(j.data&&j.data.status==='up')?'1':'0')}catch(e){console.log('0')}")
if [ "$ok" != "1" ]; then
  msg="[ALERT $(ts)] Intel NG health not ok: $body"
  echo "$msg"
  if [ -n "$WEBHOOK" ]; then
    curl -s -X POST -H "Content-Type: application/json" \
      -d "{\"text\":\"$msg\"}" "$WEBHOOK" >/dev/null || true
  fi
  exit 2
fi

echo "[OK $(ts)] $BASE health up"
exit 0
