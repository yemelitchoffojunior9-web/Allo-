/** @type {import('@playwright/test').PlaywrightTestConfig} */
const config = {
  testDir: "./tests",
  timeout: 45000,
  retries: 0,
  use: {
    baseURL: process.env.BASE_URL || "http://127.0.0.1:8787",
    headless: true,
    viewport: { width: 390, height: 844 },
    locale: "fr-FR",
  },
  webServer: process.env.SKIP_WEBSERVER
    ? undefined
    : {
        command: "node backend/server.js",
        url: "http://127.0.0.1:8787/api/health",
        reuseExistingServer: true,
        timeout: 30000,
        env: {
          PORT: "8787",
          INTEL_NG_DATA_DIR: process.env.INTEL_NG_DATA_DIR || "/tmp/intel-ng-e2e",
        },
      },
};
module.exports = config;
