#!/usr/bin/env node
const BASE = process.env.BASE_URL || "http://127.0.0.1:8787";
async function req(method, path, body, token) {
  const headers = { Accept: "application/json", "Content-Type": "application/json" };
  if (token) headers.Authorization = "Bearer " + token;
  const res = await fetch(BASE + path, {
    method,
    headers,
    body: body != null ? JSON.stringify(body) : undefined,
  });
  const json = await res.json().catch(() => ({}));
  if (!json.ok) throw new Error(method + " " + path + " → " + (json.error || res.status));
  return json.data;
}
(async () => {
  console.log("API smoke against", BASE);
  const h = await req("GET", "/api/health");
  console.log("health", h.status, h.engine);
  const phone = "+23767" + Math.floor(1000000 + Math.random() * 8999999);
  const reg = await req("POST", "/api/auth/register", { phone, password: "secret12" });
  console.log("register invite", reg.user.invite);
  const dep = await req(
    "POST",
    "/api/wallet/deposit",
    {
      amount: 4000,
      provider: "MTN",
      accountName: "S",
      screenshot: "data:image/png;base64,iVBORw0KGgo=" + Date.now(),
      clientAt: new Date().toISOString(),
    },
    reg.token
  );
  const adm = await req("POST", "/api/admin/login", {
    email: "wilstontadia@gmail.com",
    password: "IntelNG@2026",
  });
  await req("POST", "/api/admin/deposits/" + dep.id + "/approve", {}, adm.token);
  const me = await req("GET", "/api/me", null, reg.token);
  if (me.user.balance !== 4000) throw new Error("balance " + me.user.balance);
  await req(
    "POST",
    "/api/purchase",
    { name: "Pack Bienvenue", price: 3000, daily: 286, days: 21, maxBuys: 10 },
    reg.token
  );
  console.log("ALL_SMOKE_PASS");
})().catch((e) => {
  console.error("FAIL", e.message);
  process.exit(1);
});
