# Tests Intel NG (point 14)

## Smoke API (sans Playwright)
```bash
cd backend && INTEL_NG_DATA_DIR=/tmp/intel-ng-e2e node server.js
# autre terminal :
node tests/api-smoke.js
```

## Playwright
```bash
npm i -D @playwright/test
npx playwright install chromium
npx playwright test
```

Couverture : health, catalogue, register/login, dépôt→approve, achat, admin form, maintenance.
