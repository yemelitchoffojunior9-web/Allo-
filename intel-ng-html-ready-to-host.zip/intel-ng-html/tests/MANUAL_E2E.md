# Checklist E2E mobile — Intel NG (3G / Android)

Cocher sur un vrai téléphone (Chrome Android). Simuler réseau lent si possible.

## Préparation
- [ ] Cache vidé / version asset à jour (v15+)
- [ ] Mode portrait, barre d’état visible
- [ ] Ajout à l’écran d’accueil (PWA) testé

## Compte
- [ ] Inscription (pays CM +237, mot de passe ≥ 6)
- [ ] Connexion + « Se souvenir de moi »
- [ ] Lien parrain `index.html#/register?ref=CODE` préremplit le code
- [ ] Déconnexion puis reconnexion

## Portefeuille
- [ ] Recharge min 2000 refusée en dessous
- [ ] Recharge max 500000 refusée au-dessus
- [ ] Copie n° MoMo fonctionne
- [ ] Checklist preuve obligatoire
- [ ] Demande visible « En attente »
- [ ] Retrait : message clair si solde insuffisant
- [ ] Historique : filtres + recherche + pagination

## Admin
- [ ] Login email admin uniquement (pas via login téléphone)
- [ ] User ne voit pas `/admin`
- [ ] Valider dépôt → solde user crédité
- [ ] Refuser dépôt avec motif → visible user
- [ ] Valider / refuser retrait (fonds rendus si refus)
- [ ] Ticket support : répondre + clôturer
- [ ] Ajouter un second admin par email
- [ ] Export CSV dépôts

## Produits
- [ ] Onglet Activité en premier
- [ ] Prix sur bouton Acheter
- [ ] Limite 10 sur packs 3000 / 8000 (message + bouton)
- [ ] Achat → machine dans portefeuille
- [ ] Récolter gains (ou cooldown en heures)

## Parrainage
- [ ] Copier code / WhatsApp / QR
- [ ] Guide texte lisible
- [ ] Bonus après achat filleul (mock)

## Résilience
- [ ] Mode avion → bannière hors ligne
- [ ] Navigation rapide Accueil ↔ Produits : pas de spinner bloqué
- [ ] CGU + Confidentialité accessibles

## Signature testeur
Date : ________  Appareil : ________  OK global : [ ]
