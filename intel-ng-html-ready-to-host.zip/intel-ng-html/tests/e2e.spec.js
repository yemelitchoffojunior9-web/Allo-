/**
 * Playwright E2E — Intel NG
 *   npx playwright install chromium
 *   npx playwright test
 */
const { test, expect } = require("@playwright/test");

test.describe("Intel NG E2E", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/");
    await page.evaluate(() => {
      try {
        localStorage.clear();
        sessionStorage.clear();
        localStorage.setItem("intelng_onboard", "1");
      } catch (e) {}
    });
  });

  test("14.1 health API up", async ({ request }) => {
    const res = await request.get("/api/health");
    expect(res.ok()).toBeTruthy();
    const json = await res.json();
    expect(json.ok).toBeTruthy();
  });

  test("14.2 catalogue Activité en premier", async ({ page }) => {
    await page.goto("/#/product");
    await page.waitForTimeout(600);
    const firstTab = page.locator("#product-tabs .tab").first();
    await expect(firstTab).toContainText(/Activité/i);
  });

  test("14.3 register + login API", async ({ request }) => {
    const phone = "+23767" + String(Math.floor(1000000 + Math.random() * 8999999));
    const reg = await request.post("/api/auth/register", {
      data: { phone, password: "secret12", name: "E2E" },
    });
    const regJson = await reg.json();
    expect(regJson.ok).toBeTruthy();
    expect(regJson.data.user.invite).toBeTruthy();
    const login = await request.post("/api/auth/login", {
      data: { phone, password: "secret12" },
    });
    expect((await login.json()).ok).toBeTruthy();
  });

  test("14.4 depot admin approve solde", async ({ request }) => {
    const phone = "+23768" + String(Math.floor(1000000 + Math.random() * 8999999));
    const reg = await request.post("/api/auth/register", {
      data: { phone, password: "secret12" },
    });
    const token = (await reg.json()).data.token;
    const dep = await request.post("/api/wallet/deposit", {
      headers: { Authorization: "Bearer " + token },
      data: {
        amount: 5000,
        provider: "MTN MoMo",
        accountName: "E2E User",
        screenshot: "data:image/png;base64,e2e" + Date.now(),
        clientAt: new Date().toISOString(),
      },
    });
    const depId = (await dep.json()).data.id;
    const adm = await request.post("/api/admin/login", {
      data: { email: "wilstontadia@gmail.com", password: "IntelNG@2026" },
    });
    const at = (await adm.json()).data.token;
    await request.post("/api/admin/deposits/" + depId + "/approve", {
      headers: { Authorization: "Bearer " + at },
      data: {},
    });
    const me = await request.get("/api/me", {
      headers: { Authorization: "Bearer " + token },
    });
    expect((await me.json()).data.user.balance).toBe(5000);
  });

  test("14.5 achat machine", async ({ request }) => {
    const phone = "+23769" + String(Math.floor(1000000 + Math.random() * 8999999));
    const token = (
      await (
        await request.post("/api/auth/register", {
          data: { phone, password: "secret12" },
        })
      ).json()
    ).data.token;
    const depId = (
      await (
        await request.post("/api/wallet/deposit", {
          headers: { Authorization: "Bearer " + token },
          data: {
            amount: 10000,
            provider: "MTN",
            accountName: "X",
            screenshot: "data:image/png;base64,iVBORw0KGgo=" + Date.now(),
          },
        })
      ).json()
    ).data.id;
    const at = (
      await (
        await request.post("/api/admin/login", {
          data: { email: "wilstontadia@gmail.com", password: "IntelNG@2026" },
        })
      ).json()
    ).data.token;
    await request.post("/api/admin/deposits/" + depId + "/approve", {
      headers: { Authorization: "Bearer " + at },
      data: {},
    });
    const buy = await request.post("/api/purchase", {
      headers: { Authorization: "Bearer " + token },
      data: { name: "Pack Bienvenue", price: 3000, daily: 286, days: 21, maxBuys: 10 },
    });
    expect((await buy.json()).ok).toBeTruthy();
    const me = await (
      await request.get("/api/me", { headers: { Authorization: "Bearer " + token } })
    ).json();
    expect(me.data.user.balance).toBe(7000);
    expect(me.data.user.owned.length).toBeGreaterThanOrEqual(1);
  });

  test("14.6 admin form email", async ({ page }) => {
    await page.goto("/#/admin");
    await expect(page.locator("#admin-email")).toBeVisible({ timeout: 8000 });
    await expect(page.locator("#admin-pass")).toBeVisible();
  });

  test("15 maintenance page", async ({ page }) => {
    await page.goto("/#/");
    await page.evaluate(() => {
      try {
        var raw = localStorage.getItem("intelng_state");
        var st = raw ? JSON.parse(raw) : {};
        st.settings = st.settings || {};
        st.settings.maintenance = true;
        localStorage.setItem("intelng_state", JSON.stringify(st));
      } catch (e) {}
    });
    await page.goto("/#/product");
    await page.waitForTimeout(500);
    await expect(page.locator("text=Maintenance")).toBeVisible({ timeout: 5000 });
  });
});
