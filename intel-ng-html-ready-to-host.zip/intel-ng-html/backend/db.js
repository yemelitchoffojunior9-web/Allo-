/**
 * SQLite persistence (node:sqlite) + JSON migration + backups
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { DatabaseSync } = require("node:sqlite");

const os = require("os");
/* INTEL_NG_DATA_DIR pour production (disque local). Défaut: backend/data */
const DATA_DIR = process.env.INTEL_NG_DATA_DIR || path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "intel-ng.sqlite");
const JSON_LEGACY = path.join(DATA_DIR, "db.json");
/* aussi chercher l'ancien JSON à côté du package si data custom */
const JSON_LEGACY_FALLBACK = path.join(__dirname, "data", "db.json");
const BACKUP_DIR = path.join(DATA_DIR, "backups");
let _db = null;
const _stmts = Object.create(null);
let _cache = { products: null, settings: null, paymentMethods: null, stats: null, at: 0 };
const CACHE_MS = 15000;

function stmt(sql) {
  const db = open();
  if (!_stmts[sql]) _stmts[sql] = db.prepare(sql);
  return _stmts[sql];
}
function invalidateCache() {
  _cache = { products: null, settings: null, paymentMethods: null, stats: null, at: 0 };
}

function uid(prefix) {
  return (prefix || "id") + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(password), salt, 32).toString("hex");
  return salt + ":" + hash;
}
function verifyPassword(password, stored) {
  if (!stored || stored.indexOf(":") < 0) return false;
  const [salt, hash] = stored.split(":");
  const check = crypto.scryptSync(String(password), salt, 32).toString("hex");
  try { return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(check, "hex")); }
  catch (e) { return false; }
}
function safeJson(s, fb) {
  try { const v = JSON.parse(s || "null"); return v == null ? fb : v; } catch (e) { return fb; }
}

function defaultProducts() {
  return {
    Activité: [
      { id: "c1", name: "Pack Bienvenue", price: 3000, daily: 286, days: 21, image: "img/machines/thumbs/cpu1.jpg", maxBuys: 10 },
      { id: "c2", name: "Boost Week-end", price: 8000, daily: 1429, days: 14, image: "img/machines/thumbs/cpu3.jpg", maxBuys: 10 },
    ],
    Basique: [
      { id: "s1", name: "Node Starter i3", price: 12000, daily: 640, days: 40, image: "img/machines/thumbs/chip-intel-conn.jpg" },
      { id: "b1", name: "Node A1", price: 12000, daily: 640, days: 40, image: "img/machines/thumbs/chip-i7.jpg" },
      { id: "b2", name: "Node A2", price: 35000, daily: 1980, days: 45, image: "img/machines/thumbs/chip-intel486.jpg" },
    ],
    Avancé: [
      { id: "ai1", name: "Node AI Inference", price: 45000, daily: 2700, days: 45, image: "img/machines/thumbs/chip-ati.jpg" },
      { id: "a1", name: "Rack B1", price: 90000, daily: 5400, days: 50, image: "img/machines/thumbs/server-rack.jpg" },
    ],
    Premium: [
      { id: "cl1", name: "Cluster Duo", price: 70000, daily: 4200, days: 45, image: "img/machines/thumbs/chip-pins.jpg" },
      { id: "lm1", name: "Node Limited Edition", price: 100000, daily: 6000, days: 50, image: "img/machines/thumbs/chip-dark.jpg" },
    ],
  };
}

function ensureDirs() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

function setMeta(db, key, value) {
  db.prepare("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, String(value));
}
function getMeta(db, key) {
  const row = db.prepare("SELECT value FROM meta WHERE key=?").get(key);
  return row ? row.value : null;
}
function setSetting(db, key, value) {
  db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, JSON.stringify(value));
}
function getSetting(db, key, fallback) {
  const row = db.prepare("SELECT value FROM settings WHERE key=?").get(key);
  if (!row) return fallback;
  try { return JSON.parse(row.value); } catch (e) { return fallback; }
}


function ensureExtraColumns(db) {
  const alters = [
    "ALTER TABLE deposits ADD COLUMN client_at TEXT",
    "ALTER TABLE deposits ADD COLUMN submitted_label TEXT",
    "ALTER TABLE deposits ADD COLUMN proof_hash TEXT",
    "ALTER TABLE withdrawals ADD COLUMN client_at TEXT",
    "ALTER TABLE withdrawals ADD COLUMN submitted_label TEXT",
  ];
  alters.forEach((sql) => {
    try { db.exec(sql); } catch (e) { /* column exists */ }
  });
}

function migrateSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, phone TEXT UNIQUE NOT NULL, name TEXT, dial TEXT DEFAULT '+237',
      country TEXT DEFAULT 'CM', password_hash TEXT NOT NULL, invite TEXT UNIQUE,
      balance REAL DEFAULT 0, income REAL DEFAULT 0, points REAL DEFAULT 0,
      owned_json TEXT DEFAULT '[]', referrals_json TEXT DEFAULT '[]', referral_earnings REAL DEFAULT 0,
      referred_by TEXT DEFAULT '', claim_log_json TEXT DEFAULT '[]', last_claim_at TEXT,
      status TEXT DEFAULT 'actif', created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS admins (
      id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT, password_hash TEXT NOT NULL, role TEXT DEFAULT 'editor'
    );
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY, category TEXT NOT NULL, name TEXT NOT NULL, price REAL NOT NULL,
      daily REAL NOT NULL, days INTEGER NOT NULL, image TEXT, max_buys INTEGER, sort_order INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS deposits (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, phone TEXT, amount REAL NOT NULL, provider TEXT,
      account_name TEXT, screenshot TEXT, country TEXT, dial TEXT, status TEXT DEFAULT 'pending',
      reject_reason TEXT, created_at TEXT, reviewed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS withdrawals (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL, phone TEXT, amount REAL NOT NULL, method TEXT,
      mobile_provider TEXT, mobile_number TEXT, account_name TEXT, status TEXT DEFAULT 'pending',
      reject_reason TEXT, created_at TEXT, reviewed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS support_tickets (
      id TEXT PRIMARY KEY, user_id TEXT, name TEXT, email TEXT, subject TEXT, message TEXT,
      status TEXT DEFAULT 'open', admin_reply TEXT, created_at TEXT, answered_at TEXT
    );
    CREATE TABLE IF NOT EXISTS activity_log (id TEXT PRIMARY KEY, action TEXT, detail TEXT, at TEXT);
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      title TEXT,
      body TEXT,
      type TEXT DEFAULT 'info',
      read_flag INTEGER DEFAULT 0,
      created_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id);
    CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
    CREATE INDEX IF NOT EXISTS idx_users_invite ON users(invite);
    CREATE INDEX IF NOT EXISTS idx_dep_status ON deposits(status);
    CREATE INDEX IF NOT EXISTS idx_wd_status ON withdrawals(status);
  `);
}

function seedIfEmpty(db) {
  if (db.prepare("SELECT COUNT(*) AS c FROM admins").get().c > 0) return;
  db.prepare("INSERT INTO admins(id,email,name,password_hash,role) VALUES(?,?,?,?,?)")
    .run("adm1", "wilstontadia@gmail.com", "Wilston", hashPassword("IntelNG@2026"), "super");
  let order = 0;
  const ins = db.prepare("INSERT INTO products(id,category,name,price,daily,days,image,max_buys,sort_order) VALUES(?,?,?,?,?,?,?,?,?)");
  const products = defaultProducts();
  Object.keys(products).forEach((cat) => {
    products[cat].forEach((p) => {
      ins.run(p.id, cat, p.name, p.price, p.daily, p.days, p.image || "", p.maxBuys != null ? p.maxBuys : null, order++);
    });
  });
  const defaults = {
    maintenance: false, siteName: "Intel NG", referralBonusPercent: 25,
    minDeposit: 2000, maxDeposit: 500000, minWithdraw: 2000, maxWithdraw: 500000, minPassword: 6,
  };
  Object.keys(defaults).forEach((k) => setSetting(db, k, defaults[k]));
  setSetting(db, "paymentMethods", {
    mobileMoney: {
      enabled: true,
      providers: [
        { name: "MTN MoMo", number: "670 000 001", accountName: "Intel NG SARL" },
        { name: "Orange Money", number: "690 000 002", accountName: "Intel NG SARL" },
        { name: "Wave", number: "670 000 003", accountName: "Intel NG SARL" },
      ],
      instructions: "1) Envoyez le montant exact. 2) Capture. 3) Envoyez la preuve.",
    },
  });
  setSetting(db, "stats", { purchases: 0, registrations: 0, logins: 0 });
  setMeta(db, "schema", "1");
}

function migrateFromJsonIfNeeded(db) {
  if (getMeta(db, "json_migrated") === "1") return;
  const jsonPath = fs.existsSync(JSON_LEGACY) ? JSON_LEGACY : (fs.existsSync(JSON_LEGACY_FALLBACK) ? JSON_LEGACY_FALLBACK : null);
  if (!jsonPath) { setMeta(db, "json_migrated", "1"); return; }
  let data;
  try { data = JSON.parse(fs.readFileSync(jsonPath, "utf8")); } catch (e) { setMeta(db, "json_migrated", "1"); return; }
  try {
    db.exec("BEGIN");
    if (data.products) {
      db.prepare("DELETE FROM products").run();
      let order = 0;
      const ins = db.prepare("INSERT OR REPLACE INTO products(id,category,name,price,daily,days,image,max_buys,sort_order) VALUES(?,?,?,?,?,?,?,?,?)");
      Object.keys(data.products).forEach((cat) => {
        (data.products[cat] || []).forEach((p) => {
          ins.run(p.id, cat, p.name, p.price, p.daily, p.days, p.image || "", p.maxBuys != null ? p.maxBuys : null, order++);
        });
      });
    }
    if (Array.isArray(data.admins) && data.admins.length) {
      db.prepare("DELETE FROM admins").run();
      const insA = db.prepare("INSERT INTO admins(id,email,name,password_hash,role) VALUES(?,?,?,?,?)");
      data.admins.forEach((a) => insA.run(a.id, a.email, a.name || a.email, a.passwordHash || hashPassword("ChangeMe@2026"), a.role || "editor"));
    }
    if (Array.isArray(data.users)) {
      const insU = db.prepare(`INSERT OR REPLACE INTO users(
        id,phone,name,dial,country,password_hash,invite,balance,income,points,owned_json,referrals_json,
        referral_earnings,referred_by,claim_log_json,last_claim_at,status,created_at
      ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      data.users.forEach((u) => {
        insU.run(u.id, u.phone, u.name || "Utilisateur", u.dial || "+237", u.country || "CM",
          u.passwordHash || hashPassword("temp"), u.invite || null, Number(u.balance)||0, Number(u.income)||0,
          Number(u.points)||0, JSON.stringify(u.owned||[]), JSON.stringify(u.referrals||[]),
          Number(u.referralEarnings)||0, u.referredBy||"", JSON.stringify(u.claimLog||[]),
          u.lastClaimAt||null, u.status||"actif", u.createdAt || new Date().toISOString());
      });
    }
    (data.deposits || []).forEach((d) => {
      db.prepare(`INSERT OR REPLACE INTO deposits(id,user_id,phone,amount,provider,account_name,screenshot,country,dial,status,reject_reason,created_at,reviewed_at,proof_hash)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
        d.id, d.userId, d.phone, d.amount, d.provider||"", d.accountName||"", d.screenshot||"",
        d.country||"", d.dial||"", d.status||"pending", d.rejectReason||null,
        d.createdAt || new Date().toISOString(), d.reviewedAt||null, d.proofHash||"");
    });
    (data.withdrawals || []).forEach((w) => {
      db.prepare(`INSERT OR REPLACE INTO withdrawals(id,user_id,phone,amount,method,mobile_provider,mobile_number,account_name,status,reject_reason,created_at,reviewed_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(
        w.id, w.userId, w.phone, w.amount, w.method||"momo", w.mobileProvider||"", w.mobileNumber||"",
        w.accountName||"", w.status||"pending", w.rejectReason||null,
        w.createdAt || new Date().toISOString(), w.reviewedAt||null);
    });
    (data.supportTickets || []).forEach((t) => {
      db.prepare(`INSERT OR REPLACE INTO support_tickets(id,user_id,name,email,subject,message,status,admin_reply,created_at,answered_at)
        VALUES(?,?,?,?,?,?,?,?,?,?)`).run(
        t.id, t.userId, t.name, t.email, t.subject||"", t.message||"", t.status||"open",
        t.adminReply||"", t.createdAt || new Date().toISOString(), t.answeredAt||null);
    });
    if (data.settings) Object.keys(data.settings).forEach((k) => setSetting(db, k, data.settings[k]));
    if (data.paymentMethods) setSetting(db, "paymentMethods", data.paymentMethods);
    if (data.stats) setSetting(db, "stats", data.stats);
    setMeta(db, "json_migrated", "1");
    db.exec("COMMIT");
    try { fs.renameSync(JSON_LEGACY, JSON_LEGACY + ".migrated"); } catch (e) {}
    console.log("[db] Migrated db.json → SQLite");
  } catch (e) {
    try { db.exec("ROLLBACK"); } catch (e2) {}
    console.error("[db] migration failed", e);
  }
}

function open() {
  if (_db) return _db;
  ensureDirs();
  _db = new DatabaseSync(DB_FILE);
  _db.exec("PRAGMA journal_mode = DELETE;");
  _db.exec("PRAGMA synchronous = NORMAL;");
  _db.exec("PRAGMA temp_store = MEMORY;");
  _db.exec("PRAGMA foreign_keys = ON;");
  _db.exec("PRAGMA busy_timeout = 5000;");
  migrateSchema(_db);
  ensureExtraColumns(_db);
  seedIfEmpty(_db);
  migrateFromJsonIfNeeded(_db);
  /* clear prepared cache on new connection */
  for (const k of Object.keys(_stmts)) delete _stmts[k];
  invalidateCache();
  return _db;
}

function mapUser(row) {
  if (!row) return null;
  return {
    id: row.id, phone: row.phone, name: row.name, dial: row.dial, country: row.country,
    passwordHash: row.password_hash, invite: row.invite,
    balance: Number(row.balance)||0, income: Number(row.income)||0, points: Number(row.points)||0,
    owned: safeJson(row.owned_json, []), referrals: safeJson(row.referrals_json, []),
    referralEarnings: Number(row.referral_earnings)||0, referredBy: row.referred_by || "",
    claimLog: safeJson(row.claim_log_json, []), lastClaimAt: row.last_claim_at,
    status: row.status || "actif", createdAt: row.created_at,
  };
}

function publicUser(u) {
  if (!u) return null;
  return {
    id: u.id, name: u.name, phone: u.phone, dial: u.dial || "+237", country: u.country || "CM",
    invite: u.invite, balance: Number(u.balance)||0, income: Number(u.income)||0, points: Number(u.points)||0,
    team: (u.referrals && u.referrals.length) || 0, owned: u.owned || [], referrals: u.referrals || [],
    referralEarnings: Number(u.referralEarnings)||0, referredBy: u.referredBy || "",
    claimLog: u.claimLog || [], lastClaimAt: u.lastClaimAt || null, loggedIn: true, status: u.status || "actif",
  };
}

function loadProducts(db) {
  if (_cache.products && Date.now() - _cache.at < CACHE_MS) return _cache.products;
  const productRows = stmt("SELECT id,category,name,price,daily,days,image,max_buys FROM products ORDER BY sort_order ASC").all();
  const products = {};
  productRows.forEach((p) => {
    if (!products[p.category]) products[p.category] = [];
    const item = { id: p.id, name: p.name, price: p.price, daily: p.daily, days: p.days, image: p.image };
    if (p.max_buys != null) item.maxBuys = p.max_buys;
    products[p.category].push(item);
  });
  _cache.products = products;
  _cache.at = Date.now();
  return products;
}

function loadSettingsBundle(db) {
  if (_cache.settings && Date.now() - _cache.at < CACHE_MS) {
    return {
      settings: _cache.settings,
      paymentMethods: _cache.paymentMethods,
      stats: _cache.stats,
    };
  }
  const settings = {
    maintenance: getSetting(db, "maintenance", false),
    siteName: getSetting(db, "siteName", "Intel NG"),
    referralBonusPercent: getSetting(db, "referralBonusPercent", 25),
    minDeposit: getSetting(db, "minDeposit", 2000),
    maxDeposit: getSetting(db, "maxDeposit", 500000),
    minWithdraw: getSetting(db, "minWithdraw", 2000),
    maxWithdraw: getSetting(db, "maxWithdraw", 500000),
    minPassword: getSetting(db, "minPassword", 6),
  };
  const paymentMethods = getSetting(db, "paymentMethods", { mobileMoney: { enabled: true, providers: [] } });
  const stats = getSetting(db, "stats", { purchases: 0, registrations: 0, logins: 0 });
  _cache.settings = settings;
  _cache.paymentMethods = paymentMethods;
  _cache.stats = stats;
  _cache.at = Date.now();
  return { settings, paymentMethods, stats };
}

function read() {
  const db = open();
  const users = stmt("SELECT * FROM users").all().map(mapUser);
  const admins = stmt("SELECT id, email, name, password_hash AS passwordHash, role FROM admins").all();
  const products = loadProducts(db);
  /* LIMIT pour rester rapide même avec beaucoup d'historique */
  const deposits = stmt("SELECT * FROM deposits ORDER BY created_at DESC LIMIT 300").all().map((d) => ({
    id: d.id, userId: d.user_id, phone: d.phone, amount: d.amount, provider: d.provider,
    accountName: d.account_name, screenshot: d.screenshot, country: d.country, dial: d.dial,
    status: d.status, rejectReason: d.reject_reason, createdAt: d.created_at, reviewedAt: d.reviewed_at,
    clientAt: d.client_at || d.created_at,
    submittedLabel: d.submitted_label || "",
    proofHash: d.proof_hash || "",
  }));
  const withdrawals = stmt("SELECT * FROM withdrawals ORDER BY created_at DESC LIMIT 300").all().map((w) => ({
    id: w.id, userId: w.user_id, phone: w.phone, amount: w.amount, method: w.method,
    mobileProvider: w.mobile_provider, mobileNumber: w.mobile_number, accountName: w.account_name,
    status: w.status, rejectReason: w.reject_reason, createdAt: w.created_at, reviewedAt: w.reviewed_at,
    clientAt: w.client_at || w.created_at,
    submittedLabel: w.submitted_label || "",
  }));
  const supportTickets = stmt("SELECT * FROM support_tickets ORDER BY created_at DESC LIMIT 200").all().map((t) => ({
    id: t.id, userId: t.user_id, name: t.name, email: t.email, subject: t.subject, message: t.message,
    status: t.status, adminReply: t.admin_reply, createdAt: t.created_at, answeredAt: t.answered_at,
  }));
  const activityLog = stmt("SELECT id, action, detail, at FROM activity_log ORDER BY at DESC LIMIT 200").all()
    .map((l) => ({ id: l.id, action: l.action, detail: l.detail, at: l.at }));
  const bundle = loadSettingsBundle(db);
  return {
    users, admins, products, deposits, withdrawals, supportTickets, activityLog,
    settings: bundle.settings,
    paymentMethods: bundle.paymentMethods,
    stats: bundle.stats,
  };
}

function persistSnapshot(db, data) {
  db.exec("BEGIN");
  try {
    Object.keys(data.settings || {}).forEach((k) => setSetting(db, k, data.settings[k]));
    if (data.paymentMethods) setSetting(db, "paymentMethods", data.paymentMethods);
    if (data.stats) setSetting(db, "stats", data.stats);

    const upsUser = db.prepare(`INSERT INTO users(
      id,phone,name,dial,country,password_hash,invite,balance,income,points,owned_json,referrals_json,
      referral_earnings,referred_by,claim_log_json,last_claim_at,status,created_at
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET
      phone=excluded.phone, name=excluded.name, dial=excluded.dial, country=excluded.country,
      password_hash=excluded.password_hash, invite=excluded.invite, balance=excluded.balance,
      income=excluded.income, points=excluded.points, owned_json=excluded.owned_json,
      referrals_json=excluded.referrals_json, referral_earnings=excluded.referral_earnings,
      referred_by=excluded.referred_by, claim_log_json=excluded.claim_log_json,
      last_claim_at=excluded.last_claim_at, status=excluded.status`);
    (data.users || []).forEach((u) => {
      upsUser.run(u.id, u.phone, u.name || "Utilisateur", u.dial || "+237", u.country || "CM",
        u.passwordHash || hashPassword("x"), u.invite || null, Number(u.balance)||0, Number(u.income)||0,
        Number(u.points)||0, JSON.stringify(u.owned||[]), JSON.stringify(u.referrals||[]),
        Number(u.referralEarnings)||0, u.referredBy||"", JSON.stringify(u.claimLog||[]),
        u.lastClaimAt||null, u.status||"actif", u.createdAt || new Date().toISOString());
    });

    const upsDep = db.prepare(`INSERT INTO deposits(id,user_id,phone,amount,provider,account_name,screenshot,country,dial,status,reject_reason,created_at,reviewed_at,client_at,submitted_label,proof_hash)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET status=excluded.status, reject_reason=excluded.reject_reason,
        reviewed_at=excluded.reviewed_at, amount=excluded.amount, screenshot=excluded.screenshot,
        client_at=excluded.client_at, submitted_label=excluded.submitted_label, proof_hash=excluded.proof_hash`);
    (data.deposits || []).forEach((d) => {
      upsDep.run(d.id, d.userId, d.phone, d.amount, d.provider||"", d.accountName||"", d.screenshot||"",
        d.country||"", d.dial||"", d.status||"pending", d.rejectReason||null,
        d.createdAt || new Date().toISOString(), d.reviewedAt||null,
        d.clientAt || d.createdAt || null, d.submittedLabel || null, d.proofHash || null);
    });

    const upsWd = db.prepare(`INSERT INTO withdrawals(id,user_id,phone,amount,method,mobile_provider,mobile_number,account_name,status,reject_reason,created_at,reviewed_at,client_at,submitted_label)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET status=excluded.status, reject_reason=excluded.reject_reason,
        reviewed_at=excluded.reviewed_at, amount=excluded.amount,
        client_at=excluded.client_at, submitted_label=excluded.submitted_label`);
    (data.withdrawals || []).forEach((w) => {
      upsWd.run(w.id, w.userId, w.phone, w.amount, w.method||"momo", w.mobileProvider||"", w.mobileNumber||"",
        w.accountName||"", w.status||"pending", w.rejectReason||null,
        w.createdAt || new Date().toISOString(), w.reviewedAt||null,
        w.clientAt || w.createdAt || null, w.submittedLabel || null);
    });

    const upsT = db.prepare(`INSERT INTO support_tickets(id,user_id,name,email,subject,message,status,admin_reply,created_at,answered_at)
      VALUES(?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET status=excluded.status, admin_reply=excluded.admin_reply, answered_at=excluded.answered_at`);
    (data.supportTickets || []).forEach((t) => {
      upsT.run(t.id, t.userId, t.name, t.email, t.subject||"", t.message||"", t.status||"open",
        t.adminReply||"", t.createdAt || new Date().toISOString(), t.answeredAt||null);
    });

    const upsA = db.prepare(`INSERT INTO admins(id,email,name,password_hash,role) VALUES(?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET email=excluded.email, name=excluded.name, password_hash=excluded.password_hash, role=excluded.role`);
    (data.admins || []).forEach((a) => upsA.run(a.id, a.email, a.name||a.email, a.passwordHash, a.role||"editor"));
    const adminIds = (data.admins || []).map((a) => a.id);
    if (adminIds.length) {
      db.prepare(`DELETE FROM admins WHERE id NOT IN (${adminIds.map(() => "?").join(",")})`).run(...adminIds);
    }

    /* activity_log : upsert nouveaux + purge au-delà de 200 */
    const insL = stmt("INSERT OR REPLACE INTO activity_log(id,action,detail,at) VALUES(?,?,?,?)");
    (data.activityLog || []).slice(0, 50).forEach((l) => {
      insL.run(l.id || uid("log"), l.action || "", l.detail || "", l.at || new Date().toISOString());
    });
    db.prepare(`DELETE FROM activity_log WHERE id NOT IN (
      SELECT id FROM activity_log ORDER BY at DESC LIMIT 200
    )`).run();

    /* products : réécrire seulement si le catalogue a changé (hash simple) */
    if (data.products) {
      const sig = JSON.stringify(data.products);
      const prev = getMeta(db, "products_sig");
      if (prev !== sig) {
        db.prepare("DELETE FROM products").run();
        let order = 0;
        const insP = stmt("INSERT INTO products(id,category,name,price,daily,days,image,max_buys,sort_order) VALUES(?,?,?,?,?,?,?,?,?)");
        Object.keys(data.products).forEach((cat) => {
          (data.products[cat] || []).forEach((p) => {
            insP.run(p.id, cat, p.name, p.price, p.daily, p.days, p.image||"", p.maxBuys != null ? p.maxBuys : null, order++);
          });
        });
        setMeta(db, "products_sig", sig);
      }
    }
    db.exec("COMMIT");
    invalidateCache();
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}

function update(mutator) {
  const db = open();
  const snapshot = read();
  mutator(snapshot);
  persistSnapshot(db, snapshot);
  return snapshot;
}
function write(data) { persistSnapshot(open(), data); }
function log(database, action, detail) {
  database.activityLog = database.activityLog || [];
  database.activityLog.unshift({ id: uid("log"), action, detail: detail || "", at: new Date().toISOString() });
  if (database.activityLog.length > 500) database.activityLog.length = 500;
}

function backupNow(label) {
  open();
  ensureDirs();
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const name = "intel-ng-" + (label || "manual") + "-" + stamp + ".sqlite";
  const dest = path.join(BACKUP_DIR, name);
  fs.copyFileSync(DB_FILE, dest);
  pruneBackups(14);
  return dest;
}
function pruneBackups(keepDays) {
  const maxAge = (keepDays || 14) * 86400000;
  const now = Date.now();
  try {
    fs.readdirSync(BACKUP_DIR).forEach((f) => {
      if (!f.endsWith(".sqlite")) return;
      const p = path.join(BACKUP_DIR, f);
      if (now - fs.statSync(p).mtimeMs > maxAge) fs.unlinkSync(p);
    });
  } catch (e) {}
}
function listBackups() {
  ensureDirs();
  return fs.readdirSync(BACKUP_DIR).filter((f) => f.endsWith(".sqlite")).map((f) => {
    const p = path.join(BACKUP_DIR, f);
    const st = fs.statSync(p);
    return { name: f, path: p, size: st.size, mtime: st.mtime.toISOString() };
  }).sort((a, b) => (a.mtime < b.mtime ? 1 : -1));
}
function restoreBackup(fileName) {
  const src = path.join(BACKUP_DIR, path.basename(fileName));
  if (!fs.existsSync(src)) throw new Error("backup_not_found");
  backupNow("pre-restore");
  if (_db) { try { _db.close(); } catch (e) {} _db = null; }
  fs.copyFileSync(src, DB_FILE);
  for (const k of Object.keys(_stmts)) delete _stmts[k];
  invalidateCache();
  open();
  return true;
}
function health() {
  try {
    const db = open();
    return {
      ok: true, engine: "sqlite", file: DB_FILE,
      users: db.prepare("SELECT COUNT(*) AS c FROM users").get().c,
      pendingDeposits: db.prepare("SELECT COUNT(*) AS c FROM deposits WHERE status='pending'").get().c,
      backups: listBackups().length,
    };
  } catch (e) { return { ok: false, error: String(e && e.message) }; }
}
function close() {
  if (_db) { try { _db.close(); } catch (e) {} _db = null; }
}

function pushNotification(userId, title, body, type) {
  const db = open();
  const id = uid("n");
  stmt("INSERT INTO notifications(id,user_id,title,body,type,read_flag,created_at) VALUES(?,?,?,?,?,?,?)")
    .run(id, userId, title || "", body || "", type || "info", 0, new Date().toISOString());
  return id;
}
function listNotifications(userId, limit) {
  return stmt("SELECT id, title, body, type, read_flag AS read, created_at AS at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT ?")
    .all(userId, limit || 50)
    .map((n) => ({ id: n.id, title: n.title, body: n.body, type: n.type, read: !!n.read, at: n.at }));
}
function markNotificationsRead(userId, id) {
  if (!id) {
    stmt("UPDATE notifications SET read_flag=1 WHERE user_id=?").run(userId);
  } else {
    stmt("UPDATE notifications SET read_flag=1 WHERE user_id=? AND id=?").run(userId, id);
  }
}

function setMetaKey(key, value) { return setMeta(open(), key, value); }
function getMetaKey(key) { return getMeta(open(), key); }

module.exports = {
  setMeta: setMetaKey, getMeta: getMetaKey,

  pushNotification, listNotifications, markNotificationsRead,
  uid, read, write, update, log, publicUser, hashPassword, verifyPassword, defaultProducts,
  backupNow, listBackups, restoreBackup, pruneBackups, health, close, open,
  DATA_DIR, DB_FILE, BACKUP_DIR,
};
