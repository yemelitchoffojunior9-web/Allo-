/**
 * Intel NG API — Node HTTP pur (aucune dépendance npm)
 */
try { require("./load-env").loadEnv(); } catch (e) {}

const major = Number(process.versions.node.split(".")[0]);
if (major < 22) {
  console.error("FATAL: Node.js >= 22 requis (actuel: " + process.version + ")");
  process.exit(1);
}

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { URL } = require("url");
const db = require("./db-factory");

const sec = require("./security");
const proofs = require("./proofs");
const notify = require("./notify");

const PORT = Number(process.env.PORT) || 8787;
const JWT_SECRET = sec.JWT_SECRET || process.env.JWT_SECRET || "intel-ng-dev-secret-change-me";
const ROOT = path.join(__dirname, "..");
sec.assertJwtSecret();

/* ---- minimal JWT HS256 ---- */
function b64url(input) {
  return Buffer.from(input).toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function signJwt(payload, secret, expiresSec) {
  const header = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = Object.assign({}, payload, { exp: Math.floor(Date.now() / 1000) + (expiresSec || 86400) });
  const mid = b64url(JSON.stringify(body));
  const sig = crypto.createHmac("sha256", secret).update(header + "." + mid).digest("base64")
    .replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  return header + "." + mid + "." + sig;
}
function verifyJwt(token, secret) {
  if (!token) return null;
  const parts = String(token).split(".");
  if (parts.length !== 3) return null;
  const [h, m, s] = parts;
  const expect = crypto.createHmac("sha256", secret).update(h + "." + m).digest("base64")
    .replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  if (s !== expect) return null;
  try {
    const payload = JSON.parse(Buffer.from(m.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch (e) { return null; }
}

function inviteCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 6; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function formatDouala(iso) {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleString("fr-FR", {
      timeZone: "Africa/Douala",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }) + " (Douala)";
  } catch (e) {
    return String(iso);
  }
}
function settingsSafe(s) {

  return {
    maintenance: !!(s && s.maintenance),
    siteName: (s && s.siteName) || "Intel NG",
    referralBonusPercent: (s && s.referralBonusPercent) || 25,
    minDeposit: (s && s.minDeposit) || 2000,
    maxDeposit: (s && s.maxDeposit) || 500000,
    minWithdraw: (s && s.minWithdraw) || 2000,
    maxWithdraw: (s && s.maxWithdraw) || 500000,
    minPassword: (s && s.minPassword) || 6,
  };
}

function sendJson(res, status, obj, extraHeaders) {
  const body = JSON.stringify(obj);
  const origin = res._corsOrigin && res._corsOrigin !== "null" ? res._corsOrigin : "";
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
  };
  /* credentials + Origin * interdit par les navigateurs */
  if (origin) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Access-Control-Allow-Credentials"] = "true";
    headers["Vary"] = "Origin";
  } else {
    headers["Access-Control-Allow-Origin"] = "*";
  }
  if (extraHeaders) Object.assign(headers, extraHeaders);
  res.writeHead(status, headers);
  res.end(body);
}
function ok(res, data) { sendJson(res, 200, { ok: true, status: 200, data: data || {} }); }
function fail(res, status, error) { sendJson(res, status, { ok: false, status, error }); }

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch (e) { reject(e); }
    });
    req.on("error", reject);
  });
}

function getBearer(req, prefer) {
  const h = req.headers.authorization || "";
  if (h.startsWith("Bearer ")) return h.slice(7);
  const cookies = sec.parseCookies(req);
  if (prefer === "admin") return cookies.intelng_admin_token || "";
  return cookies.intelng_token || "";
}

function mime(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const map = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
  };
  return map[ext] || "application/octet-stream";
}

function acceptGzip(req) {
  const ae = String(req.headers["accept-encoding"] || "");
  return ae.includes("gzip");
}

function cacheHeaders(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if ([".jpg", ".jpeg", ".png", ".webp", ".svg", ".woff2", ".ico"].includes(ext)) {
    return { "Cache-Control": "public, max-age=2592000, immutable" }; // 30j
  }
  if ([".js", ".css"].includes(ext)) {
    return { "Cache-Control": "public, max-age=86400" }; // 1j (versionné ?v=)
  }
  if (ext === ".html" || filePath.endsWith("sw.js")) {
    return { "Cache-Control": "no-cache, must-revalidate" };
  }
  return { "Cache-Control": "public, max-age=300" };
}

function sendFile(req, res, filePath) {
  const type = mime(filePath);
  const headers = Object.assign({ "Content-Type": type }, cacheHeaders(filePath));
  const compressible =
    type.includes("javascript") ||
    type.includes("css") ||
    type.includes("json") ||
    type.includes("html") ||
    type.includes("svg");
  if (compressible && acceptGzip(req)) {
    const zlib = require("zlib");
    headers["Content-Encoding"] = "gzip";
    headers["Vary"] = "Accept-Encoding";
    res.writeHead(200, headers);
    fs.createReadStream(filePath).pipe(zlib.createGzip()).pipe(res);
    return;
  }
  res.writeHead(200, headers);
  fs.createReadStream(filePath).pipe(res);
}

function serveStatic(req, res, urlPath) {
  let rel = decodeURIComponent(urlPath.split("?")[0]);
  if (rel === "/" || rel === "") rel = "/index.html";
  const filePath = path.normalize(path.join(ROOT, rel));
  if (!filePath.startsWith(ROOT)) return fail(res, 403, "forbidden");
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    const idx = path.join(ROOT, "index.html");
    if (fs.existsSync(idx)) return sendFile(req, res, idx);
    return fail(res, 404, "not_found");
  }
  sendFile(req, res, filePath);
}


async function dbUpdate(mutator) {
  const r = db.update(mutator);
  return r && typeof r.then === "function" ? await r : r;
}
async function dbSetMeta(k, v) {
  const r = db.setMeta(k, v);
  return r && typeof r.then === "function" ? await r : r;
}
async function dbGetMeta(k) {
  const r = db.getMeta(k);
  return r && typeof r.then === "function" ? await r : r;
}
async function dbPushNotif(userId, title, body, type) {
  const r = db.pushNotification(userId, title, body, type);
  return r && typeof r.then === "function" ? await r : r;
}

async function handleApi(req, res, pathname) {
  const method = req.method || "GET";
  let body = {};
  if (method === "POST" || method === "PUT" || method === "PATCH") {
    try { body = await readBody(req); } catch (e) { return fail(res, 400, "bad_json"); }
  }

  const data = db.read();

  // health
  if (method === "GET" && pathname === "/api/health") {
    const h = db.health();
    const mem = process.memoryUsage();
    return ok(res, {
      status: h.ok ? "up" : "degraded",
      ts: Date.now(),
      uptimeSec: Math.floor(process.uptime()),
      version: "1.1.0",
      engine: h.engine || "unknown",
      users: h.users,
      pendingDeposits: h.pendingDeposits,
      backups: h.backups,
      memoryMB: Math.round((mem.rss || 0) / 1048576),
      error: h.ok ? undefined : h.error,
    });
  }

  // bootstrap
  if (method === "GET" && pathname === "/api/bootstrap") {
    let user = null;
    const payload = verifyJwt(getBearer(req), JWT_SECRET);
    if (payload && payload.typ === "user") {
      user = (data.users || []).find((u) => u.id === payload.id) || null;
    }
    return ok(res, {
      products: data.products,
      settings: settingsSafe(data.settings),
      paymentMethods: data.paymentMethods,
      notice: "Règlement des gains chaque jour à 00:00 (heure de Douala). Dépôt min. 2 000 FCFA.",
      user: user ? db.publicUser(user) : null,
    });
  }

  // register
  if (method === "POST" && pathname === "/api/auth/register") {
    if (sec.rateLimit(req, "register", 8, 15 * 60 * 1000)) return fail(res, 429, "rate_limit");
    if (data.settings && data.settings.maintenance) return fail(res, 503, "maintenance");
    const phone = sec.normalizePhone(body.phone || "", body.dial || "+237");
    const password = String(body.password || "");
    const code = String(body.invite || body.code || "").trim().toUpperCase();
    const min = (data.settings && data.settings.minPassword) || 6;
    if (phone.replace(/\D/g, "").length < 7) return fail(res, 400, "phone");
    if (password.length < min) return fail(res, 400, "password");
    const phoneDigits = phone.replace(/\D/g, "");
    if ((data.users || []).some((u) => u.phone === phone || String(u.phone).replace(/\D/g, "") === phoneDigits)) {
      return fail(res, 409, "exists");
    }
    let referredBy = "";
    let sponsor = null;
    if (code) {
      sponsor = (data.users || []).find((u) => String(u.invite || "").toUpperCase() === code);
      if (sponsor) referredBy = sponsor.id;
    }
    const user = {
      id: db.uid("u"), phone, name: String(body.name || "Utilisateur"),
      dial: body.dial || "+237", country: body.country || "CM",
      passwordHash: db.hashPassword(password), invite: inviteCode(),
      balance: 0, income: 0, points: 0, owned: [], referrals: [], referralEarnings: 0,
      referredBy, claimLog: [], lastClaimAt: null, status: "actif",
      createdAt: new Date().toISOString(),
    };
    await dbUpdate((d) => {
      d.users.push(user);
      d.stats.registrations = (d.stats.registrations || 0) + 1;
      if (sponsor) {
        const sp = d.users.find((u) => u.id === sponsor.id);
        if (sp) {
          sp.referrals = sp.referrals || [];
          const dig = phone.replace(/\D/g, "");
          sp.referrals.unshift({
            id: db.uid("ref"), phone: dig.slice(0, 2) + "****" + dig.slice(-3),
            userId: user.id, joinedAt: new Date().toISOString(), status: "inscrit", invested: false, bonusPaid: 0,
          });
        }
      }
      db.log(d, "register", phone);
    });
    const token = signJwt({ typ: "user", id: user.id, phone }, JWT_SECRET, 30 * 86400);
    sec.auditAppend(db.DATA_DIR, { action: "register", phone, userId: user.id, ip: sec.clientKey(req) });
    return sendJson(res, 200, { ok: true, status: 200, data: { token, user: db.publicUser(user) } }, {
      "Set-Cookie": sec.cookieHeader("intelng_token", token, 30 * 86400),
    });
  }

  // login
  if (method === "POST" && pathname === "/api/auth/login") {
    if (sec.rateLimit(req, "login", 10, 15 * 60 * 1000)) return fail(res, 429, "rate_limit");
    if (data.settings && data.settings.maintenance) return fail(res, 503, "maintenance");
    const phone = sec.normalizePhone(body.phone || "", body.dial || "+237");
    const password = String(body.password || "");
    const phoneDigits = phone.replace(/\D/g, "");
    const user = (data.users || []).find((u) => u.phone === phone || String(u.phone).replace(/\D/g, "") === phoneDigits);
    if (!user || !db.verifyPassword(password, user.passwordHash)) return fail(res, 401, "credentials");
    if (user.status === "suspendu") return fail(res, 403, "forbidden");
    await dbUpdate((d) => {
      d.stats.logins = (d.stats.logins || 0) + 1;
      const u = d.users.find((x) => x.id === user.id);
      if (u && !u.invite) u.invite = inviteCode();
      db.log(d, "login", phone);
    });
    const fresh = db.read().users.find((x) => x.id === user.id) || user;
    const tokenL = signJwt({ typ: "user", id: fresh.id, phone }, JWT_SECRET, 30 * 86400);
    sec.auditAppend(db.DATA_DIR, { action: "login", phone, userId: fresh.id, ip: sec.clientKey(req) });
    return sendJson(res, 200, { ok: true, status: 200, data: { token: tokenL, user: db.publicUser(fresh) } }, {
      "Set-Cookie": sec.cookieHeader("intelng_token", tokenL, 30 * 86400),
    });
  }

  // me
  if (method === "GET" && pathname === "/api/me") {
    const payload = verifyJwt(getBearer(req), JWT_SECRET);
    if (!payload || payload.typ !== "user") return fail(res, 401, "unauthorized");
    const user = (db.read().users || []).find((u) => u.id === payload.id);
    if (!user) return fail(res, 401, "unauthorized");
    return ok(res, { user: db.publicUser(user) });
  }
  if (method === "PUT" && pathname === "/api/me") {
    const payload = verifyJwt(getBearer(req), JWT_SECRET);
    if (!payload || payload.typ !== "user") return fail(res, 401, "unauthorized");
    const name = String(body.name || "").trim();
    if (name && name.length < 2) return fail(res, 400, "name");
    let updated = null;
    await dbUpdate((d) => {
      const u = (d.users || []).find((x) => x.id === payload.id);
      if (!u) return;
      if (name) u.name = name;
      updated = u;
    });
    if (!updated) return fail(res, 401, "unauthorized");
    return ok(res, { user: db.publicUser(updated) });
  }

  function requireUser() {
    const payload = verifyJwt(getBearer(req), JWT_SECRET);
    if (!payload || payload.typ !== "user") return null;
    return (db.read().users || []).find((u) => u.id === payload.id) || null;
  }
  function requireAdmin() {
    const payload = verifyJwt(getBearer(req, "admin"), JWT_SECRET);
    if (!payload || payload.typ !== "admin") return null;
    return (db.read().admins || []).find((a) => a.id === payload.id) || null;
  }


  // mot de passe oublié
  if (method === "POST" && pathname === "/api/auth/forgot") {
    if (sec.rateLimit(req, "forgot", 5, 15 * 60 * 1000)) return fail(res, 429, "rate_limit");
    const phone = sec.normalizePhone(body.phone || "", body.dial || "+237");
    const data = db.read();
    const user = (data.users || []).find((u) => u.phone === phone || String(u.phone).replace(/\D/g, "") === phone.replace(/\D/g, ""));
    /* Toujours OK pour ne pas révéler si le numéro existe */
    if (user) {
      const code = String(Math.floor(100000 + Math.random() * 900000));
      const exp = Date.now() + 15 * 60 * 1000;
      const dig = phone.replace(/\D/g, "");
      await dbSetMeta("reset:" + dig, JSON.stringify({ code: code, exp: exp, userId: user.id }));
      const msg = "Intel NG — code de réinitialisation : " + code + " (valable 15 min).";
      try {
        await notify.notifyUser(user, { subject: "Réinitialisation mot de passe", text: msg, prefer: body.channel === "email" ? "email" : "sms" });
      } catch (e) {}
      if (process.env.NODE_ENV !== "production") {
        return ok(res, { sent: true, devCode: code });
      }
    }
    return ok(res, { sent: true });
  }

  if (method === "POST" && pathname === "/api/auth/reset") {
    if (sec.rateLimit(req, "reset", 8, 15 * 60 * 1000)) return fail(res, 429, "rate_limit");
    const phone = sec.normalizePhone(body.phone || "", body.dial || "+237");
    const code = String(body.code || "").trim();
    const password = String(body.password || "");
    const min = (db.read().settings && db.read().settings.minPassword) || 6;
    if (password.length < min) return fail(res, 400, "password");
    if (!code || code.length < 4) return fail(res, 400, "invalid_code");
    const dig = phone.replace(/\D/g, "");
    let payload = null;
    try { payload = JSON.parse(await dbGetMeta("reset:" + dig) || "null"); } catch (e) { payload = null; }
    if (!payload || String(payload.code) !== code || Date.now() > Number(payload.exp || 0)) {
      return fail(res, 400, "invalid_code");
    }
    let done = false;
    await dbUpdate((d) => {
      const u = (d.users || []).find((x) => x.id === payload.userId || x.phone === phone || String(x.phone).replace(/\D/g, "") === dig);
      if (!u) return;
      u.passwordHash = db.hashPassword(password);
      done = true;
      db.log(d, "password_reset", phone);
    });
    await dbSetMeta("reset:" + dig, "");
    if (!done) return fail(res, 400, "invalid_code");
    sec.auditAppend(db.DATA_DIR, { action: "password_reset", phone });
    return ok(res, {});
  }

  // deposit
  if (method === "POST" && pathname === "/api/wallet/deposit") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    if (sec.rateLimit(req, "deposit", 12, 60 * 60 * 1000)) return fail(res, 429, "rate_limit");
    const dataNow = db.read();
    const stg = dataNow.settings || {};
    const amountErr = sec.validateAmount(body.amount, stg.minDeposit || 2000, stg.maxDeposit || 500000);
    if (amountErr) return fail(res, 400, amountErr);
    const amount = Number(body.amount);
    const pendingCount = (dataNow.deposits || []).filter((x) => x.userId === user.id && x.status === "pending").length;
    if (pendingCount >= 3) return fail(res, 400, "too_many_pending");
    const proof = sec.validateProof(body.screenshot);
    if (!proof.ok) return fail(res, 400, proof.error);
    const shot = String(body.screenshot || "");
    const fp = proofs.proofFingerprint(shot);
    const dup = (dataNow.deposits || []).find((x) => x.proofHash === fp && x.status !== "rejected");
    if (dup) return fail(res, 400, "duplicate_proof");
    const depId = db.uid("dep");
    let shotRef = "";
    try {
      const saved = proofs.saveProof(shot, depId);
      shotRef = saved.url; /* chemin public, pas le base64 */
    } catch (e) {
      return fail(res, 400, e.message === "proof_too_large" ? "proof_too_large" : "proof_type");
    }
    const nowIso = new Date().toISOString();
    const clientAt = String(body.clientAt || body.localAt || "").slice(0, 40) || nowIso;
    const dep = {
      id: depId, userId: user.id, phone: user.phone, amount,
      provider: sec.cleanText(body.provider || "", 40), accountName: sec.cleanText(body.accountName || "", 80),
      screenshot: shotRef, proofHash: fp, country: sec.cleanText(body.country || user.country, 8),
      dial: body.dial || user.dial, status: "pending",
      createdAt: nowIso,
      clientAt: clientAt,
      submittedLabel: formatDouala(nowIso),
      clientLabel: formatDouala(clientAt),
    };
    await dbUpdate((d) => { d.deposits.unshift(dep); db.log(d, "deposit_request", dep.id); });
    return ok(res, { id: dep.id });
  }

  // withdraw
  if (method === "POST" && pathname === "/api/wallet/withdraw") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    if (sec.rateLimit(req, "withdraw", 10, 60 * 60 * 1000)) return fail(res, 429, "rate_limit");
    const s = db.read().settings || {};
    const amountErrW = sec.validateAmount(body.amount, s.minWithdraw || 2000, s.maxWithdraw || 500000);
    if (amountErrW) return fail(res, 400, amountErrW);
    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount <= 0) return fail(res, 400, "invalid_amount");
    if (amount > (Number(user.balance) || 0)) return fail(res, 400, "balance");
    const nowIsoW = new Date().toISOString();
    const clientAtW = String(body.clientAt || body.localAt || "").slice(0, 40) || nowIsoW;
    const w = {
      id: db.uid("wd"), userId: user.id, phone: user.phone, amount,
      method: body.method || "momo", mobileProvider: sec.cleanText(body.mobileProvider || "", 40),
      mobileNumber: sec.cleanText(body.mobileNumber || "", 20), accountName: sec.cleanText(body.accountName || "", 80),
      status: "pending",
      createdAt: nowIsoW,
      clientAt: clientAtW,
      submittedLabel: formatDouala(nowIsoW),
      clientLabel: formatDouala(clientAtW),
    };
    let wdOk = false;
    await dbUpdate((d) => {
      const u = d.users.find((x) => x.id === user.id);
      if (!u) return;
      const bal = Number(u.balance) || 0;
      if (amount > bal) return;
      u.balance = bal - amount;
      d.withdrawals = d.withdrawals || [];
      d.withdrawals.unshift(w);
      db.log(d, "withdraw_request", w.id);
      wdOk = true;
    });
    if (!wdOk) return fail(res, 400, "balance");
    return ok(res, { id: w.id });
  }

  // claim
  if (method === "POST" && pathname === "/api/wallet/claim") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    const dayMs = 24 * 60 * 60 * 1000;
    const now = Date.now();
    let total = 0, claimed = 0, nextInMs = dayMs;
    await dbUpdate((d) => {
      const u = d.users.find((x) => x.id === user.id);
      if (!u) return;
      (u.owned || []).forEach((o) => {
        const days = Number(o.days) || 0;
        const daily = Number(o.daily) || 0;
        const start = o.startedAt ? new Date(o.startedAt).getTime() : now;
        const maxEarn = daily * days;
        if (days > 0 && ((now - start) >= days * dayMs || (o.earned || 0) >= maxEarn)) { o.status = "completed"; return; }
        const last = o.lastClaimAt ? new Date(o.lastClaimAt).getTime() : 0;
        if (last && now - last < dayMs) {
          const remain = dayMs - (now - last);
          if (remain > 0 && remain < nextInMs) nextInMs = remain;
          return;
        }
        const next = Math.min(daily, Math.max(0, maxEarn - (Number(o.earned) || 0)));
        if (next <= 0) { o.status = "completed"; return; }
        o.earned = (Number(o.earned) || 0) + next;
        o.lastClaimAt = new Date().toISOString();
        total += next; claimed++;
      });
      if (total > 0) {
        u.income = (Number(u.income) || 0) + total;
        u.balance = (Number(u.balance) || 0) + total;
        u.lastClaimAt = new Date().toISOString();
        u.claimLog = u.claimLog || [];
        u.claimLog.unshift({ at: new Date().toISOString(), amount: total, count: claimed });
        db.log(d, "claim", u.phone + " +" + total);
      }
    });
    if (total <= 0) {
      const u = db.read().users.find((x) => x.id === user.id);
      if (!(u && u.owned && u.owned.length)) return fail(res, 400, "no_income");
      return fail(res, 400, "cooldown:" + Math.max(1, Math.ceil(nextInMs / 3600000)));
    }
    return ok(res, { amount: total, count: claimed });
  }

  // purchase
  if (method === "POST" && pathname === "/api/purchase") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    const price = Number(body.price);
    const name = String(body.name || "");
    let maxBuys = body.maxBuys != null ? Number(body.maxBuys) : null;
    if (maxBuys == null && (price === 3000 || price === 8000)) maxBuys = 10;
    if ((Number(user.balance) || 0) < price) return fail(res, 400, "balance");
    if (maxBuys != null) {
      const bought = (user.owned || []).filter((o) => o.name === name || Number(o.price) === price).length;
      if (bought >= maxBuys) return fail(res, 400, "max_buys");
    }
    await dbUpdate((d) => {
      const u = d.users.find((x) => x.id === user.id);
      u.balance = (Number(u.balance) || 0) - price;
      u.owned = u.owned || [];
      u.owned.unshift({
        id: db.uid("own"), name, price, daily: Number(body.daily) || 0, days: Number(body.days) || 0,
        image: body.image || "", earned: 0, status: "active",
        startedAt: new Date().toISOString(), lastClaimAt: null,
      });
      d.stats.purchases = (d.stats.purchases || 0) + 1;
      if (u.referredBy) {
        const pct = (d.settings && d.settings.referralBonusPercent) || 25;
        const bonus = Math.floor((price * pct) / 100);
        const sp = d.users.find((x) => x.id === u.referredBy);
        if (sp && bonus > 0) {
          sp.balance = (Number(sp.balance) || 0) + bonus;
          sp.referralEarnings = (Number(sp.referralEarnings) || 0) + bonus;
        }
      }
      db.log(d, "purchase", u.phone + " " + name);
    });
    return ok(res, { ok: true });
  }

  // support
  if (method === "POST" && pathname === "/api/support") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    const ticket = {
      id: db.uid("t"), userId: user.id, name: sec.cleanText(body.name || user.name, 80),
      email: sec.cleanText(body.email || user.phone, 120), subject: sec.cleanText(body.subject || "", 120),
      message: sec.cleanText(body.message || "", 2000),
      status: "open", adminReply: "", createdAt: new Date().toISOString(),
    };
    await dbUpdate((d) => { d.supportTickets.unshift(ticket); db.log(d, "support", ticket.id); });
    return ok(res, { id: ticket.id });
  }
  if (method === "GET" && pathname === "/api/support/mine") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    return ok(res, { tickets: (db.read().supportTickets || []).filter((t) => t.userId === user.id) });
  }
  if (method === "GET" && pathname === "/api/wallet/history") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    const d = db.read();
    const u = (d.users || []).find((x) => x.id === user.id) || user;
    return ok(res, {
      deposits: (d.deposits || []).filter((x) => x.userId === user.id),
      withdrawals: (d.withdrawals || []).filter((x) => x.userId === user.id),
      claims: (u.claimLog || []).map((c) => ({
        kind: "claim",
        amount: c.amount,
        count: c.count,
        at: c.at,
        status: "approved",
      })),
      owned: u.owned || [],
    });
  }

  // admin login
  if (method === "POST" && pathname === "/api/admin/login") {
    if (sec.rateLimit(req, "admin_login", 8, 15 * 60 * 1000)) return fail(res, 429, "rate_limit");
    const email = String(body.email || "").trim().toLowerCase();
    const password = String(body.password || "");
    const admin = (data.admins || []).find((a) => String(a.email).toLowerCase() === email);
    if (!admin || !db.verifyPassword(password, admin.passwordHash)) return fail(res, 401, "credentials");
    await dbUpdate((d) => db.log(d, "admin_login", email));
    const admTok = signJwt({ typ: "admin", id: admin.id, email: admin.email, role: admin.role }, JWT_SECRET, 12 * 3600);
    sec.auditAppend(db.DATA_DIR, { action: "admin_login", email: admin.email, ip: sec.clientKey(req) });
    return sendJson(res, 200, {
      ok: true, status: 200,
      data: {
        token: admTok,
        admin: { id: admin.id, email: admin.email, name: admin.name, role: admin.role },
      },
    }, {
      "Set-Cookie": sec.cookieHeader("intelng_admin_token", admTok, 12 * 3600),
    });
  }

  // admin routes
  const admin = requireAdmin();
  if (pathname.startsWith("/api/admin/") && pathname !== "/api/admin/login") {
    if (!admin) return fail(res, 401, "unauthorized");
  }

  if (method === "GET" && pathname === "/api/admin/deposits") return ok(res, { deposits: db.read().deposits || [] });
  if (method === "GET" && pathname === "/api/admin/withdrawals") return ok(res, { withdrawals: db.read().withdrawals || [] });
  if (method === "GET" && pathname === "/api/admin/users") {
    return ok(res, { users: (db.read().users || []).map((u) => ({
      id: u.id, phone: u.phone, name: u.name, balance: Number(u.balance) || 0,
      income: Number(u.income) || 0, status: u.status || "actif", createdAt: u.createdAt,
      team: (u.referrals || []).length,
    })) });
  }
  if (method === "GET" && pathname === "/api/admin/tickets") return ok(res, { tickets: db.read().supportTickets || [] });
  if (method === "GET" && pathname === "/api/admin/admins") {
    return ok(res, {
      admins: (db.read().admins || []).map((a) => ({ id: a.id, email: a.email, name: a.name, role: a.role })),
    });
  }
  if (method === "GET" && pathname === "/api/admin/logs") return ok(res, { logs: (db.read().activityLog || []).slice(0, 100) });
  if (method === "GET" && pathname === "/api/admin/dashboard") {
    const d = db.read();
    return ok(res, {
      users: d.users.length,
      pendingDeposits: d.deposits.filter((x) => x.status === "pending").length,
      pendingWithdrawals: d.withdrawals.filter((x) => x.status === "pending").length,
      openTickets: d.supportTickets.filter((t) => t.status === "open").length,
      stats: d.stats,
      settings: settingsSafe(d.settings),
    });
  }

  // approve/reject deposit
  let m;
  if (method === "POST" && (m = pathname.match(/^\/api\/admin\/deposits\/([^/]+)\/approve$/))) {
    let found = false;
    let approvedDep = null;
    await dbUpdate((d) => {
      const dep = (d.deposits || []).find((x) => x.id === m[1] && x.status === "pending");
      if (!dep) return;
      found = true;
      dep.status = "approved";
      dep.reviewedAt = new Date().toISOString();
      dep.reviewedLabel = formatDouala(dep.reviewedAt);
      const u = d.users.find((x) => x.id === dep.userId);
      if (u) u.balance = (Number(u.balance) || 0) + Number(dep.amount);
      else db.log(d, "deposit_approve_orphan", dep.id);
      db.log(d, "deposit_approve", m[1]);
      sec.auditAppend(db.DATA_DIR, { action: "deposit_approve", depositId: m[1], amount: dep.amount, userId: dep.userId });
      approvedDep = { userId: dep.userId, amount: dep.amount, id: dep.id };
    });
    if (approvedDep) {
      try {
        await dbPushNotif(approvedDep.userId, "Dépôt validé", "+" + approvedDep.amount + " FCFA crédités sur votre solde.", "success");
      } catch (e) {}
      try {
        const uu = (db.read().users || []).find((x) => x.id === approvedDep.userId);
        if (uu) {
          await notify.notifyUser(uu, {
            subject: "Dépôt validé — Intel NG",
            text: "Votre dépôt de " + approvedDep.amount + " FCFA a été validé. Solde mis à jour.",
          });
        }
      } catch (e) {}
    }
    return found ? ok(res, {}) : fail(res, 404, "not_found");
  }
  if (method === "POST" && (m = pathname.match(/^\/api\/admin\/deposits\/([^/]+)\/reject$/))) {
    let found = false;
    let rejected = null;
    await dbUpdate((d) => {
      const dep = (d.deposits || []).find((x) => x.id === m[1] && x.status === "pending");
      if (!dep) return;
      found = true;
      dep.status = "rejected";
      dep.rejectReason = sec.cleanText(body.reason || "Refusé par l'administrateur", 200);
      db.log(d, "deposit_reject", m[1]);
      rejected = { userId: dep.userId, reason: dep.rejectReason };
    });
    if (rejected) {
      try { await dbPushNotif(rejected.userId, "Dépôt refusé", rejected.reason, "error"); } catch (e) {}
    }
    return found ? ok(res, {}) : fail(res, 404, "not_found");
  }
  if (method === "POST" && (m = pathname.match(/^\/api\/admin\/withdrawals\/([^/]+)\/approve$/))) {
    let found = false;
    let paid = null;
    await dbUpdate((d) => {
      const w = (d.withdrawals || []).find((x) => x.id === m[1] && x.status === "pending");
      if (!w) return;
      found = true;
      w.status = "approved";
      db.log(d, "withdraw_approve", m[1]);
      paid = { userId: w.userId, amount: w.amount };
    });
    if (paid) {
      try { await dbPushNotif(paid.userId, "Retrait payé", paid.amount + " FCFA envoyés.", "success"); } catch (e) {}
      try {
        const uu = (db.read().users || []).find((x) => x.id === paid.userId);
        if (uu) await notify.notifyUser(uu, { subject: "Retrait effectué", text: paid.amount + " FCFA ont été envoyés." });
      } catch (e) {}
    }
    return found ? ok(res, {}) : fail(res, 404, "not_found");
  }
  if (method === "POST" && (m = pathname.match(/^\/api\/admin\/withdrawals\/([^/]+)\/reject$/))) {
    let found = false;
    let rejW = null;
    await dbUpdate((d) => {
      const w = (d.withdrawals || []).find((x) => x.id === m[1] && x.status === "pending");
      if (!w) return;
      found = true;
      w.status = "rejected";
      w.rejectReason = sec.cleanText(body.reason || "Refusé", 200);
      const u = d.users.find((x) => x.id === w.userId);
      if (u) u.balance = (Number(u.balance) || 0) + Number(w.amount);
      db.log(d, "withdraw_reject", m[1]);
      rejW = { userId: w.userId, reason: w.rejectReason };
    });
    if (rejW) {
      try { await dbPushNotif(rejW.userId, "Retrait refusé", rejW.reason + " — fonds restitués.", "error"); } catch (e) {}
    }
    return found ? ok(res, {}) : fail(res, 404, "not_found");
  }
  if (method === "POST" && (m = pathname.match(/^\/api\/admin\/tickets\/([^/]+)\/reply$/))) {
    let found = false;
    await dbUpdate((d) => {
      const t = (d.supportTickets || []).find((x) => x.id === m[1]);
      if (!t) return;
      found = true;
      t.adminReply = String(body.reply || "").slice(0, 500);
      t.status = "answered";
      db.log(d, "support_reply", m[1]);
    });
    return found ? ok(res, {}) : fail(res, 404, "not_found");
  }
  if (method === "POST" && pathname === "/api/admin/admins") {
    const email = String(body.email || "").trim().toLowerCase();
    if (!email || email.indexOf("@") < 0) return fail(res, 400, "email");
    await dbUpdate((d) => {
      if ((d.admins || []).some((a) => String(a.email).toLowerCase() === email)) return;
      d.admins.push({
        id: db.uid("adm"), email, name: body.name || email,
        passwordHash: db.hashPassword(body.password || "ChangeMe@2026"), role: "editor",
      });
      db.log(d, "admin_add", email);
    });
    return ok(res, {});
  }
  if (method === "DELETE" && (m = pathname.match(/^\/api\/admin\/admins\/([^/]+)$/))) {
    await dbUpdate((d) => {
      if ((d.admins || []).length <= 1) return;
      d.admins = d.admins.filter((a) => a.id !== m[1]);
    });
    return ok(res, {});
  }

  /* ---- Notifications user ---- */
  if (method === "GET" && pathname === "/api/notifications") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    return ok(res, { notifications: db.listNotifications(user.id, 50) });
  }
  if (method === "POST" && pathname === "/api/notifications/read") {
    const user = requireUser();
    if (!user) return fail(res, 401, "unauthorized");
    db.markNotificationsRead(user.id, body.id || null);
    return ok(res, {});
  }

  /* ---- CRUD machines (admin) ---- */
  if (method === "GET" && pathname === "/api/admin/products") {
    if (!requireAdmin()) return fail(res, 401, "unauthorized");
    return ok(res, { products: db.read().products });
  }
  if (method === "POST" && pathname === "/api/admin/products") {
    if (!requireAdmin()) return fail(res, 401, "unauthorized");
    const cat = String(body.category || "Machines").trim() || "Machines";
    const name = String(body.name || "").trim();
    const price = Number(body.price);
    const daily = Number(body.daily);
    const days = Number(body.days);
    if (!name || !(price > 0) || !(daily >= 0) || !(days > 0)) return fail(res, 400, "invalid_product");
    const id = db.uid("p");
    await dbUpdate((d) => {
      d.products = d.products || {};
      d.products[cat] = d.products[cat] || [];
      d.products[cat].push({
        id, name, price, daily, days,
        image: body.image || "img/machines/thumbs/cpu1.jpg",
        maxBuys: body.maxBuys != null ? Number(body.maxBuys) : undefined,
      });
      db.log(d, "product_add", name);
    });
    return ok(res, { id, products: db.read().products });
  }
  if (method === "PUT" && (m = pathname.match(/^\/api\/admin\/products\/([^/]+)$/))) {
    if (!requireAdmin()) return fail(res, 401, "unauthorized");
    let found = false;
    await dbUpdate((d) => {
      Object.keys(d.products || {}).forEach((cat) => {
        (d.products[cat] || []).forEach((p) => {
          if (p.id !== m[1]) return;
          found = true;
          if (body.name) p.name = String(body.name);
          if (body.price != null) p.price = Number(body.price);
          if (body.daily != null) p.daily = Number(body.daily);
          if (body.days != null) p.days = Number(body.days);
          if (body.image != null) p.image = body.image;
          if (body.maxBuys != null) p.maxBuys = Number(body.maxBuys);
        });
      });
      if (found) db.log(d, "product_edit", m[1]);
    });
    return found ? ok(res, { products: db.read().products }) : fail(res, 404, "not_found");
  }
  if (method === "DELETE" && (m = pathname.match(/^\/api\/admin\/products\/([^/]+)$/))) {
    if (!requireAdmin()) return fail(res, 401, "unauthorized");
    await dbUpdate((d) => {
      Object.keys(d.products || {}).forEach((cat) => {
        d.products[cat] = (d.products[cat] || []).filter((p) => p.id !== m[1]);
      });
      db.log(d, "product_del", m[1]);
    });
    return ok(res, { products: db.read().products });
  }

  if (method === "GET" && pathname === "/api/admin/backups") {
    if (!requireAdmin()) return fail(res, 401, "unauthorized");
    return ok(res, { backups: db.listBackups() });
  }
  if (method === "POST" && pathname === "/api/admin/backups") {
    if (!requireAdmin()) return fail(res, 401, "unauthorized");
    const p = db.backupNow("manual");
    return ok(res, { path: p, backups: db.listBackups() });
  }

  return fail(res, 404, "not_found");
}


const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") {
      const origin = req.headers.origin || "*";
      res.writeHead(204, {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
        "Access-Control-Allow-Credentials": "true",
        "Vary": "Origin",
      });
      return res.end();
    }
    res._corsOrigin = req.headers.origin || "*";
    const u = new URL(req.url || "/", "http://127.0.0.1");
    if (u.pathname.startsWith("/api/")) return await handleApi(req, res, u.pathname);
    /* Preuves dépôt (fichiers hors DB) */
    if (u.pathname.startsWith("/media/proofs/")) {
      const full = proofs.resolveProofFile(u.pathname.replace("/media/", ""));
      if (!full) return fail(res, 404, "not_found");
      const ext = path.extname(full).toLowerCase();
      const types = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif" };
      res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "private, max-age=3600" });
      return fs.createReadStream(full).pipe(res);
    }

    return serveStatic(req, res, u.pathname);
  } catch (e) {
    console.error(e);
    return fail(res, 500, "server_error");
  }
});

// reset db if old bcrypt hashes present
try {
  const d = db.read();
  const a = (d.admins || [])[0];
  if (a && a.passwordHash && a.passwordHash.indexOf(":") < 0) {
    fs.unlinkSync(db.DB_FILE);
    db.read();
    console.log("DB reset (new hash format)");
  }
} catch (e) {}

/* Backup quotidien automatique (toutes les 24h) + un au démarrage */
try {
  db.backupNow("startup");
  setInterval(function () {
    try {
      const p = db.backupNow("daily");
      console.log("[backup]", p);
    } catch (e) {
      console.error("[backup] fail", e && e.message);
    }
  }, 24 * 60 * 60 * 1000);
} catch (e) {
  console.error("[backup] init", e && e.message);
}

async function startServer() {
  if (db.warm) {
    try {
      await db.warm();
      console.log("[db] warmed, engine=", db.engine || "sqlite");
    } catch (e) {
      console.error("[db] warm failed", e);
      process.exit(1);
    }
  }
  try {
    const envEmail = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
    const envPass = process.env.ADMIN_PASSWORD || "";
    if (envEmail && envPass && envPass.length >= 8) {
      await dbUpdate((d) => {
        let a = (d.admins || []).find((x) => String(x.email).toLowerCase() === envEmail);
        if (!a) {
          a = { id: db.uid("adm"), email: envEmail, name: "Admin", passwordHash: db.hashPassword(envPass), role: "super" };
          d.admins = d.admins || [];
          d.admins.push(a);
        } else {
          a.passwordHash = db.hashPassword(envPass);
        }
      });
      console.log("[security] Admin password set from ADMIN_EMAIL / ADMIN_PASSWORD");
    }
  } catch (e) {
    console.error("[security] admin bootstrap", e && e.message);
  }
  server.listen(PORT, "0.0.0.0", () => {
    console.log("Intel NG on http://127.0.0.1:" + PORT);
    console.log("DB engine:", db.engine || "sqlite", "| data:", process.env.INTEL_NG_DATA_DIR || "backend/data");
    console.log("NODE_ENV=", process.env.NODE_ENV || "development", "| HTTPS cookies Secure=", !!sec.IS_PROD);
    if (!sec.IS_PROD) console.log("Admin défaut: changez via ADMIN_EMAIL / ADMIN_PASSWORD en prod");
    console.log("Health: http://127.0.0.1:" + PORT + "/api/health");
  });
}
startServer();
