#!/usr/bin/env bash
set -e
URL="${1:-http://127.0.0.1:8787}"
OUT_DIR="${2:-./lighthouse-reports}"
mkdir -p "$OUT_DIR"
STAMP=$(date +%Y%m%d-%H%M%S)
REPORT="$OUT_DIR/report-$STAMP"

echo "Lighthouse mobile → $URL"
echo "Rapport → $REPORT.html"

npx --yes lighthouse "$URL" \
  --only-categories=performance,accessibility,best-practices \
  --form-factor=mobile \
  --screenEmulation.mobile=true \
  --throttling-method=devtools \
  --chrome-flags="--headless --no-sandbox --disable-gpu" \
  --output=html,json \
  --output-path="$REPORT" \
  --quiet

node -e "
  const r=require('./$REPORT.json'.replace('././','./'));
" 2>/dev/null || true

node << NODE
const fs = require("fs");
const path = "$REPORT.json";
try {
  const r = JSON.parse(fs.readFileSync(path, "utf8"));
  const p = r.categories && r.categories.performance;
  const a = r.categories && r.categories.accessibility;
  const b = r.categories && r.categories["best-practices"];
  const score = p ? Math.round(p.score * 100) : 0;
  console.log("Performance:", score);
  console.log("Accessibilité:", a ? Math.round(a.score * 100) : "?");
  console.log("Bonnes pratiques:", b ? Math.round(b.score * 100) : "?");
  if (score < 80) {
    console.log("Objectif: Performance >= 80 (actuel: " + score + ")");
    process.exitCode = 2;
  } else console.log("Objectif Performance >= 80: OK");
} catch (e) {
  console.error("Impossible de lire le rapport JSON:", e.message);
}
NODE
echo "Ouvrir: $REPORT.html"
