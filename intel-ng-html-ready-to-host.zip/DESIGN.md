# Design system Intel NG

## Tokens
- `--background`, `--card`, `--accent-cyan`, `--accent-teal`, `--muted`, `--danger`

## Composants
- `.btn-primary` / `.btn-outline` / `.btn-danger` / `.btn-xs`
- `.card` / `.card-pad`
- `.field-box` + `.field-label`
- `.toast` (success | error | info)
- `.modal-box`
- `.skeleton`
- `.admin-*` (panel admin)

## Page live
Ouvrir `#/design` dans l'app.
