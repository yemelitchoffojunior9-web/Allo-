# CDN, optimisation d’images et Lazy Loading — Intel NG

## 1. Configurer le CDN

Fichier : `js/cdn.js`

```js
// Exemple Cloudflare R2 / Bunny / jsDelivr
g.CDN.setCdnBase("https://cdn.mondomaine.com/intel-ng");
g.CDN.enableCdn(true);

// Désactiver (tout en local)
g.CDN.enableCdn(false);
// ou
g.CDN.config.CDN_BASE = "";
```

Ou directement dans `js/cdn.js` :

```js
CDN_BASE: "https://cdn.mondomaine.com/intel-ng",
USE_CDN: true,
ASSET_VERSION: "6",
```

Puis uploader le dossier `img/` (et `register-banner.jpg`) vers ce chemin CDN.

Toutes les images passent par `CDN.assetUrl(path)` →  
`img/machines/thumbs/cpu1.jpg` devient  
`https://cdn…/img/machines/thumbs/cpu1.jpg?v=6`.

---

## 2. Exemples de Lazy Loading

### A. Attribut natif (déjà utilisé dans le site)

```html
<img
  src="img/machines/thumbs/chip-i7.jpg"
  alt="Node A1"
  width="400"
  height="240"
  loading="lazy"
  decoding="async"
  fetchpriority="low"
/>
```

- `loading="lazy"` : le navigateur ne charge l’image **que** quand elle approche de l’écran.
- `decoding="async"` : décodage hors du thread principal.
- `fetchpriority="low"` : priorise le texte / CSS d’abord.

### B. Helper JS du site (`UI.mediaHtml`)

```js
// Bannière importante (above the fold)
g.UI.mediaHtml("register-banner.jpg", { eager: true, alt: "Intel NG" });

// Carte produit (lazy)
g.UI.mediaHtml("img/machines/thumbs/chip-i7.jpg", {
  alt: "Node A1",
  className: "product-media media-wrap is-loading",
});
```

### C. Intersection Observer (exemple avancé)

```js
const io = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    const img = entry.target;
    img.src = img.dataset.src; // data-src → src
    img.removeAttribute("data-src");
    io.unobserve(img);
  });
}, { rootMargin: "200px" });

document.querySelectorAll("img[data-src]").forEach((img) => io.observe(img));
```

```html
<img data-src="img/machines/thumbs/cpu1.jpg" alt="" width="400" height="240" />
```

### D. Avec CDN + lazy

```js
const src = g.CDN.assetUrl("img/machines/thumbs/chip-i7.jpg");
// → https://cdn…/img/machines/thumbs/chip-i7.jpg?v=6

g.UI.mediaHtml(src, { alt: "Machine", className: "product-media media-wrap is-loading" });
```

---

## 3. Optimisation images (« optim »)

Déjà appliqué côté projet :

| Technique | Détail |
|-----------|--------|
| Redimensionnement | Thumbs **400×240** pour le catalogue |
| Compression JPEG | Qualité ~52–58, progressive |
| Strip metadata | EXIF retiré |
| Lazy load | `loading="lazy"` |
| Cache SW | Images en cache-first (v6) |
| Version `?v=` | Invalide le cache après update |

Outils possibles en plus : Squoosh.app, ImageOptim, `cwebp`, CDN avec **Polish / Image Resizing** (Cloudflare).

---

## 4. Avantages d’un CDN

1. **Vitesse** : serveurs proches de l’utilisateur (PoP mondiaux).
2. **Moins de charge** sur ton hébergement / mobile data du serveur d’origine.
3. **Cache HTTP** agressif (Cache-Control long) sans bloquer le HTML.
4. **HTTPS + HTTP/2/3** souvent inclus.
5. **Protection** : absorption de pics de trafic, parfois DDoS.
6. **Images à la volée** (selon CDN) : WebP/AVIF, resize par URL.

## 5. Inconvénients d’un CDN

1. **Coût** après un certain volume (ou plan gratuit limité).
2. **Complexité** : config DNS, CORS, invalidation de cache.
3. **Dépendance** : si le CDN est down, les images cassent (sauf fallback local).
4. **Dev offline** : sans réseau, le CDN ne marche pas → garder `CDN_BASE = ""` en local.
5. **Invalidation** : une image remplacée peut rester en cache → d’où `?v=6`.
6. **Confidentialité / RGPD** : logs chez un tiers (choisir un CDN sérieux).

---

## 6. Recommandation pour Intel NG

| Environnement | Config |
|---------------|--------|
| Fichier local / démo offline | `CDN_BASE = ""` (défaut actuel) |
| Production web | Uploader `img/` + banner sur CDN, renseigner `CDN_BASE` |
| Images admin (data URL) | Éviter : trop lourdes ; uploader un fichier compressé |

Le site **fonctionne déjà sans CDN**. Le module `cdn.js` permet d’en brancher un **sans réécrire** toutes les pages.


---

## Cache CDN configuré

Fichiers du projet :
- `_headers` → Netlify / Cloudflare Pages
- `vercel.json` → Vercel

### Règles appliquées
| Ressource | Cache-Control |
|-----------|----------------|
| `/img/*`, `*.webp`, `*.jpg` | `public, max-age=31536000, immutable` (1 an) |
| JS / CSS | 7 jours |
| `index.html` | `must-revalidate` (toujours à jour) |

Invalidation : changer `ASSET_VERSION` dans `js/cdn.js` (ex. `7` → `8`).

### Cloudflare (manuel)
1. Cache Rules : URI Path contains `/img/` → Edge TTL 1 month, Browser TTL 1 year  
2. Optional : **Polish** + **WebP** (conversion auto côté CDN)

---

## WebP automatique

Le helper `UI.mediaHtml` génère :

```html
<picture>
  <source srcset="…/chip-i7.webp?v=7" type="image/webp" />
  <img src="…/chip-i7.jpg?v=7" width="400" height="240" loading="lazy" />
</picture>
```

- Navigateurs modernes → **WebP**
- Anciens → **JPEG** fallback
- Désactiver : `g.CDN.config.AUTO_WEBP = false`
