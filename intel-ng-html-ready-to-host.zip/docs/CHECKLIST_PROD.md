# Checklist production Intel NG

## 1. Secrets & admin
```bash
cd backend
cp .env.example .env
# JWT_SECRET=$(openssl rand -hex 32)
# ADMIN_EMAIL=...  ADMIN_PASSWORD=... (min 12)
# RESEND_API_KEY=...  ou EMAIL_WEBHOOK_URL=
# TWILIO_*  ou SMS_WEBHOOK_URL=
node check-env.js   # NODE_ENV=production
```

## 2. Fichiers à déployer
- `index.html` **ou** `intel-ng-standalone.html`
- `js/`, `styles.css`, `img/` (images obligatoires)
- `backend/` (+ `npm install` si Postgres)
- **Ne pas** uploader seulement le HTML

## 3. Lancement
```bash
cd backend && npm install   # si besoin de pg
NODE_ENV=production node check-env.js
pm2 start ecosystem.config.cjs
# Nginx/Caddy HTTPS → 127.0.0.1:8787
```

## 4. Preuves multi-serveur
```bash
# NFS
INTEL_NG_PROOFS_DIR=/mnt/nfs/intel-ng/proofs
# ou S3
S3_BUCKET=... S3_ACCESS_KEY=... S3_SECRET_KEY=... S3_ENDPOINT=...
```

## 5. Monitoring
```bash
./scripts/monitor.sh https://VOTRE_DOMAINE
# Cron toutes les 5 min + MONITOR_WEBHOOK_URL=https://discord/slack webhook
```

## 6. Vérifications
- curl https://domaine/api/health → ok, proofsWritable true
- Images visibles
- Login user + admin
