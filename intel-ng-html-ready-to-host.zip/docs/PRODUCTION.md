# Mise en production — Intel NG (front)

## Soldes

En production, **le solde affiché vient uniquement du backend**.  
Le stockage local (`localStorage`) ne doit plus être la source de vérité pour :
- balance / income
- dépôts / retraits
- machines possédées / récoltes

Le fichier `js/api.js` est le **seul** point à brancher sur l’API réelle.

## Secrets admin

Ne pas committer de mots de passe réels.  
Configurer via `window.__INTEL_NG_CONFIG__` dans `index.html` (non versionné) :

```html
<script>
window.__INTEL_NG_CONFIG__ = {
  adminBootstrap: [
    { email: "admin@votredomaine.com", password: "CHANGE_ME", name: "Admin" }
  ]
};
</script>
```

## Checklist avant go-live backend

Voir `tests/MANUAL_E2E.md`.

## Backend branché (v17)

```bash
cd backend && node server.js
```

Puis ouvrir http://127.0.0.1:8787

Les soldes sont gérés **côté serveur** (`backend/data/db.json`).

## Backend solide (v1.1)

- SQLite (`node:sqlite`) + migration `db.json`
- Backups auto (startup + 24h, 14 jours)
- PM2 : `backend/ecosystem.config.cjs`
- systemd : `backend/deploy/intel-ng.service`
- Health enrichi : `GET /api/health`

```bash
export JWT_SECRET="…long…"
export INTEL_NG_DATA_DIR=/var/lib/intel-ng
cd backend && node server.js
# ou: pm2 start ecosystem.config.cjs
```

## Point A (HTTPS, env, Node, Lighthouse)
Voir **docs/DEPLOY_A.md** et `backend/.env.example`.
