# PostgreSQL & multi-serveur

## Pourquoi
SQLite = **1 seul process Node** (PM2 `instances: 1`).  
Pour plusieurs machines / instances : **PostgreSQL**.

## Étapes
1. Créer une base Postgres
2. `psql $DATABASE_URL -f backend/deploy/schema-postgres.sql`
3. `cd backend && npm install pg`
4. Exporter :
```bash
export DATABASE_URL=postgres://user:pass@host:5432/intelng
export NODE_ENV=production
```
5. Le driver `pg` est **optionnel**. Sans `DATABASE_URL`, SQLite reste le défaut.

## État actuel du code
- **Production recommandée aujourd’hui** : SQLite + 1 instance PM2 + backups disque.
- Schéma Postgres fourni pour migration.
- Preuves déjà **hors DB** (fichiers `data/proofs/`) — compatible multi-serveur si volume partagé (NFS/S3) ou sticky sessions admin.

## Multi-serveur minimal sans Postgres
Impossible avec SQLite partagé sur réseau (corruption).  
Toujours : **1 writer** ou Postgres.

## PM2
```js
instances: 1  // SQLite
// instances: 2 // seulement avec Postgres + adapter pg
```
