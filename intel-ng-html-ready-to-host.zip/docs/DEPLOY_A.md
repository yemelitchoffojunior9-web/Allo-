# Déploiement — point A (HTTPS, .env, Node 22, Lighthouse)

## 1. Node.js ≥ 22

```bash
node -v   # doit afficher v22.x ou plus
```

Si besoin (Ubuntu) :
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs
```

Le serveur **refuse de démarrer** si Node < 22.

## 2. Fichier `.env`

```bash
cd backend
cp .env.example .env
nano .env
```

Générer le secret :
```bash
openssl rand -hex 32
```

Coller dans `JWT_SECRET=...`, renseigner `ADMIN_EMAIL` et `ADMIN_PASSWORD`.

Vérifier :
```bash
node check-env.js
```

Démarrer (charge automatiquement `.env`) :
```bash
node server.js
# ou: pm2 start ecosystem.config.cjs
```

## 3. HTTPS

### Option Nginx + Certbot
```bash
sudo apt-get install -y nginx certbot python3-certbot-nginx
# Éditer server_name dans backend/deploy/nginx-https.conf
sudo cp backend/deploy/nginx-https.conf /etc/nginx/sites-available/intel-ng
sudo ln -sf /etc/nginx/sites-available/intel-ng /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d VOTRE_DOMAINE
```

### Option Caddy (HTTPS auto)
```bash
# Éditer le domaine dans backend/deploy/Caddyfile
sudo caddy run --config backend/deploy/Caddyfile
```

Le backend reste en **HTTP local** (`127.0.0.1:8787`).  
HTTPS = reverse proxy devant.

Avec `NODE_ENV=production`, les cookies passent en **Secure** (HTTPS only).

## 4. Test Lighthouse réel

### En local (serveur déjà lancé)
```bash
cd backend && node server.js &
cd ..
./scripts/lighthouse-run.sh http://127.0.0.1:8787
```

### Sur le domaine prod
```bash
./scripts/lighthouse-run.sh https://VOTRE_DOMAINE
```

Objectif : **Performance mobile ≥ 80**.

Rapports HTML/JSON dans `lighthouse-reports/`.

## Checklist A

- [ ] Node ≥ 22
- [ ] `.env` rempli + `node check-env.js` OK
- [ ] HTTPS (certbot ou Caddy)
- [ ] `curl https://DOMAINE/api/health` → ok
- [ ] Lighthouse mobile ≥ 80 (ou plan d’amélioration images/cache)

## Résultat test réel (sandbox)
- Lighthouse mobile Performance **avant** gzip: ~68
- Lighthouse mobile Performance **après** gzip + cache + defer: **97**
- Objectif >= 80: **atteint**
