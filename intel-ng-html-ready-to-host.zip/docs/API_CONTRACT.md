# Intel NG — Contrat API (front → backend)

> Version front : v15+  
> Toutes les méthodes vivent dans `js/api.js` (`g.API`).  
> Remplacer le corps mock par `fetch('/api/...')` **sans changer les signatures**.

## Principes

1. **Soldes et transactions = serveur uniquement en production.**  
   Le `localStorage` est un mock offline. Ne jamais faire confiance au solde client.
2. Réponses normalisées :
   - succès : `{ ok: true, data: {...} }`
   - erreur : `{ ok: false, status?: number, error: string }`
3. Auth user : session / JWT après login téléphone + mot de passe.  
4. Auth admin : session séparée (email + mot de passe), rôles `super|editor|viewer`.

## Codes d'erreur fréquents

| error | Signification |
|-------|----------------|
| `maintenance` | Site en maintenance |
| `credentials` | Identifiants invalides |
| `locked` | Trop de tentatives |
| `exists` | Compte déjà inscrit |
| `balance` | Solde insuffisant |
| `max_buys` | Limite d'achats (ex. 10) |
| `min_amount` / `max_amount` | Hors plage montant |
| `cooldown:H` | Récolte dans ~H heures |
| `no_income` | Rien à récolter |
| `not_found` | Ressource absente |
| `forbidden` | Droit insuffisant |

## Auth utilisateur

### `login(phone, password)`
- In: téléphone international ou local, mot de passe  
- Out data: `{ user }`  
- Errors: `credentials`, `locked`, `maintenance`

### `register({ name, phone, password, invite? })`
- Out data: `{ user }`  
- Errors: `exists`, `maintenance`, validation

### `logout()`

## Portefeuille

### `requestDeposit({ amount, phone, provider, accountName, screenshot?, country?, dial? })`
- Montants : min 2000, max 500000, step 500 (XAF)  
- Out data: `{ id }`  
- Errors: `min_amount`, `max_amount`, …

### `requestWithdraw({ amount, method, mobileProvider, mobileNumber, accountName? })`
- Débite le solde côté serveur de façon atomique  
- Errors: `balance`, `min_amount`, `max_amount`

### `claimDailyIncome()`
- Out data: `{ amount, count }`  
- Errors: `no_income`, `cooldown:H`

## Catalogue

### `purchase(product)`
- product: `{ name, price, daily, days, image?, maxBuys? }`  
- Errors: `balance`, `max_buys`, `maintenance`

## Admin

### `adminLogin(email, password)` → session admin séparée  
### `approveDeposit(id)` / `rejectDeposit(id, reason?)`  
### `approveWithdraw(id)` / `rejectWithdraw(id, reason?)`  
### `adminAddAccount` / `adminRemoveAccount`  
### Support: clôture + réponse ticket

## Headers recommandés (prod)

```
Authorization: Bearer <token>
Content-Type: application/json
X-Request-Id: <uuid>   # idempotence dépôts/retraits/achats
```

## Idempotence

Envoyer `Idempotency-Key` sur dépôt, retrait, achat. Le serveur ignore les doublons 24 h.
