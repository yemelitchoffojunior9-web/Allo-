# Sécurité Intel NG (points 1–5)

## 1. Secrets production

```bash
export NODE_ENV=production
export JWT_SECRET="$(openssl rand -hex 32)"   # min 24 caractères
export ADMIN_EMAIL="admin@votredomaine.com"
export ADMIN_PASSWORD="MotDePasseFort!2026"
export INTEL_NG_DATA_DIR=/var/lib/intel-ng
cd backend && node server.js
```

- En `NODE_ENV=production`, un `JWT_SECRET` faible **arrête** le serveur.
- `ADMIN_EMAIL` + `ADMIN_PASSWORD` (min 8) réécrit le hash admin au démarrage.

## 2. HTTPS + cookies

- Derrière **nginx/Caddy en HTTPS**.
- Login pose un cookie `HttpOnly; SameSite=Strict` (+ `Secure` en prod).
- Le front envoie aussi `Authorization: Bearer` (double mode).
- `credentials: "include"` sur les `fetch`.

## 3. Rate-limit

| Route | Limite |
|-------|--------|
| register | 8 / 15 min / IP |
| login | 10 / 15 min / IP |
| admin login | 8 / 15 min / IP |
| deposit | 12 / heure / IP |
| withdraw | 10 / heure / IP |

Erreur API : `rate_limit` (HTTP 429).

## 4. Validation preuves & textes

- Preuve : préfixe `data:image/jpeg|png|webp;base64,`
- Taille max ~1,5 Mo (`MAX_PROOF_CHARS`)
- Montants : entier, min/max, multiple de 500
- Support / motifs de refus : échappement HTML (`cleanText`)

## 5. Audit append-only

Fichier : `$INTEL_NG_DATA_DIR/audit.jsonl`  
Une ligne JSON par événement (login, register, approve dépôt, admin login…).  
**Jamais écrasé** — seulement ajouté. Inclus dans vos backups disque.
