# Performance & CDN (point 17)

## Objectif
Lighthouse **mobile ≥ 80** (Performance), 3G/4G Cameroun.

## Mesure
```bash
npx lighthouse http://127.0.0.1:8787 --form-factor=mobile --only-categories=performance --view
```

| Métrique | Cible |
|----------|--------|
| Score Performance | ≥ 80 |
| LCP | < 2,5 s (4G) |
| CLS | < 0,1 |

## Déjà en place
- Thumbs compressées + lazy + WebP conditionnel
- Polices système (pas Google Fonts)
- Service Worker versionné
- Preload bannière critique

## CDN
```js
g.CDN.setCdnBase("https://cdn.example.com/intel-ng");
g.CDN.enableCdn(true);
```
Cache `img/*` : `Cache-Control: public, max-age=31536000, immutable`

## nginx
```nginx
gzip on;
gzip_types text/css application/javascript application/json image/svg+xml;
location /img/ {
  expires 365d;
  add_header Cache-Control "public, immutable";
}
```
